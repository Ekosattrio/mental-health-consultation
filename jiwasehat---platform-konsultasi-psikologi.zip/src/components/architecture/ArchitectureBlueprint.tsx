import React, { useState } from 'react';
import {
  Shield,
  Database,
  Server,
  Code2,
  CheckCircle2,
  XCircle,
  Lock,
  Layers,
  Sparkles,
  Copy,
  Check,
  AlertTriangle,
  Play
} from 'lucide-react';

export const ArchitectureBlueprint: React.FC = () => {
  const [activeBlueprintTab, setActiveBlueprintTab] = useState<'rbac' | 'erd' | 'api' | 'code'>('rbac');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  // Interactive Live Simulator for Booking Conflict
  const [simDate, setSimDate] = useState('2026-09-16');
  const [simTime, setSimTime] = useState('10:30');
  const [simLogs, setSimLogs] = useState<string[]>([]);
  const [simRunning, setSimRunning] = useState(false);

  const copyToClipboard = (text: string, sectionId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionId);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const runConcurrencySimulation = () => {
    setSimRunning(true);
    setSimLogs([
      `[T+0ms] Client A (Budi Santoso) dan Client B (Siti Amanda) serentak mengirim request reservasi untuk slot ${simDate} ${simTime} WIB...`,
      `[T+12ms] BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE`,
      `[T+18ms] Client A mengakuisisi Row-Level Lock: "SELECT * FROM psychologist_schedules WHERE id = $1 FOR UPDATE NOWAIT"`,
      `[T+24ms] Lock granted to Client A. Memeriksa ketersediaan: is_available = TRUE & is_booked = FALSE`,
      `[T+28ms] Client B mencoba mengeksekusi "SELECT ... FOR UPDATE": Locked by Transaction A. Worker B mengantri pada connection pool`,
      `[T+45ms] Client A: INSERT INTO appointments (...) RETURNING id; UPDATE psychologist_schedules SET is_booked = TRUE; COMMIT;`,
      `[T+50ms] Lock dilepaskan oleh Client A. Worker Client B membaca state terbaru: slot telah berstatus is_booked = TRUE`,
      `[T+55ms] EXCEPTION 409 CONFLICT: "Slot waktu ini telah terisi atau sedang dalam proses pembayaran." Transaction B ROLLBACK.`,
      `[T+60ms] Hasil: Double-booking dicegah 100%. Data integrity aman.`
    ]);
    setTimeout(() => setSimRunning(false), 800);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-8 shadow-xl border border-indigo-900/50">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-bold border border-indigo-400/30 mb-3">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              Software Architecture & System Blueprint
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight">
              Arsitektur Sistem & Spesifikasi Enterprise JiwaSehat
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl mt-2 leading-relaxed">
              Dokumentasi komprehensif Role-Based Access Control (RBAC), skema database relasional (ERD 11 tabel), desain API RESTful, serta implementasi kode kunci pencegah race-condition booking & WebSocket guard.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1.5 rounded-xl bg-slate-800 text-indigo-300 text-xs font-mono font-bold border border-slate-700">
              PostgreSQL 16 + Node.js
            </span>
          </div>
        </div>
      </div>

      {/* Blueprint Navigation Tabs */}
      <div className="flex overflow-x-auto gap-2 border-b border-slate-200 pb-2">
        {[
          { id: 'rbac', label: '1. Role & Permission Matrix (RBAC)', icon: <Shield className="w-4 h-4" /> },
          { id: 'erd', label: '2. Database Schema (ERD & SQL)', icon: <Database className="w-4 h-4" /> },
          { id: 'api', label: '3. API Endpoints & Auth Middleware', icon: <Server className="w-4 h-4" /> },
          { id: 'code', label: '4. Kode Kunci: Conflict Lock & WebSocket', icon: <Code2 className="w-4 h-4" /> }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveBlueprintTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-3 rounded-2xl text-xs font-bold transition-all whitespace-nowrap ${
              activeBlueprintTab === tab.id
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-600 hover:text-slate-900 bg-white border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* SECTION 1: ROLE & PERMISSION MATRIX (RBAC) */}
      {activeBlueprintTab === 'rbac' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
            <div className="mb-6">
              <h3 className="text-xl font-extrabold text-slate-900">Tabel Matriks Hak Akses (Role-Based Access Control)</h3>
              <p className="text-xs text-slate-500 mt-1">
                Matriks permission granular yang memisahkan boundary keamanan antara Pasien, Psikolog/Dokter, dan Administrator.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border border-slate-200 rounded-2xl overflow-hidden">
                <thead className="bg-slate-100 text-slate-700 uppercase font-bold text-[10px]">
                  <tr>
                    <th className="py-3 px-4">Modul & Kapabilitas Sistem</th>
                    <th className="py-3 px-4 text-center bg-slate-50 text-slate-500">Tamu / Publik</th>
                    <th className="py-3 px-4 text-center bg-emerald-50 text-emerald-800">Pasien (Klien)</th>
                    <th className="py-3 px-4 text-center bg-sky-50 text-sky-800">Psikolog / Dokter</th>
                    <th className="py-3 px-4 text-center bg-purple-50 text-purple-800">Administrator</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {[
                    { module: 'Melihat Profil Psikolog, Lokasi & Kontak', guest: true, pat: true, psy: true, adm: true },
                    { module: 'Melihat Testimoni & Review Publik Terverifikasi', guest: true, pat: true, psy: true, adm: true },
                    { module: 'Mengerjakan Tes Psikologi Mandiri (DASS-21)', guest: true, pat: true, psy: false, adm: false },
                    { module: 'Mengisi & Mengubah Form Intake Pasien', guest: false, pat: true, psy: false, adm: false },
                    { module: 'Reservasi Jadwal & Pembayaran Paket', guest: false, pat: true, psy: false, adm: false },
                    { module: 'Akses Ruang Live Chat Sesi Aktif', guest: false, pat: true, psy: true, adm: false, note: 'Hanya room sesi terkait' },
                    { module: 'Memberikan Rating & Ulasan Pasca-Sesi', guest: false, pat: true, psy: false, adm: false },
                    { module: 'Mengelola Profil & Biografi Profesional', guest: false, pat: false, psy: true, adm: true },
                    { module: 'Manajemen Slot Jadwal (Availability Matrix)', guest: false, pat: false, psy: true, adm: false },
                    { module: 'Melihat Hasil Tes & Intake Form Pasien Bimbingan', guest: false, pat: false, psy: true, adm: false, note: 'Protected EMR' },
                    { module: 'Menulis Catatan Perkembangan Klinis (SOAP Notes)', guest: false, pat: false, psy: true, adm: false },
                    { module: 'Verifikasi Kredensial STR / SIP Psikolog', guest: false, pat: false, psy: false, adm: true },
                    { module: 'Moderasi Review Pasien (Approve/Reject)', guest: false, pat: false, psy: false, adm: true },
                    { module: 'CRUD Paket Konsultasi & Instrumen Asesmen', guest: false, pat: false, psy: false, adm: true },
                    { module: 'Monitoring Seluruh Janji Temu & Laporan Keuangan', guest: false, pat: false, psy: false, adm: true }
                  ].map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-semibold text-slate-800">
                        {row.module}
                        {row.note && <span className="block text-[10px] text-slate-400 font-normal">*{row.note}</span>}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {row.guest ? <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" /> : <XCircle className="w-4 h-4 text-slate-300 mx-auto" />}
                      </td>
                      <td className="py-3 px-4 text-center bg-emerald-50/40">
                        {row.pat ? <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" /> : <XCircle className="w-4 h-4 text-slate-300 mx-auto" />}
                      </td>
                      <td className="py-3 px-4 text-center bg-sky-50/40">
                        {row.psy ? <CheckCircle2 className="w-4 h-4 text-sky-600 mx-auto" /> : <XCircle className="w-4 h-4 text-slate-300 mx-auto" />}
                      </td>
                      <td className="py-3 px-4 text-center bg-purple-50/40">
                        {row.adm ? <CheckCircle2 className="w-4 h-4 text-purple-600 mx-auto" /> : <XCircle className="w-4 h-4 text-slate-300 mx-auto" />}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: DATABASE SCHEMA (ERD & RELASIONAL) */}
      {activeBlueprintTab === 'erd' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 mb-6 gap-4">
              <div>
                <h3 className="text-xl font-extrabold text-slate-900">Skema Database Relasional (11 Tabel Inti)</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Mencakup relasi `users`, `roles`, `profiles`, `psychologist_schedules`, `packages`, `appointments`, `tests`, `test_results`, `chats`, `clinical_notes`, dan `reviews`.
                </p>
              </div>

              <button
                onClick={() =>
                  copyToClipboard(
                    `-- PostgreSQL Schema JiwaSehat (11 Tables DDL)\n-- Includes Foreign Keys, Indexes, and Constraints...`,
                    'sql'
                  )
                }
                className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 hover:bg-slate-800"
              >
                {copiedSection === 'sql' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>Salin Schema DDL</span>
              </button>
            </div>

            {/* Interactive Visual Entity Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                {
                  table: 'users',
                  desc: 'Entitas akun otentikasi utama',
                  cols: ['id (UUID, PK)', 'email (VARCHAR, UNIQUE)', 'password_hash (VARCHAR)', 'role_id (UUID, FK -> roles.id)', 'status (ENUM: ACTIVE, PENDING, BLOCKED)', 'created_at (TIMESTAMP)']
                },
                {
                  table: 'roles',
                  desc: 'Master permission role RBAC',
                  cols: ['id (UUID, PK)', 'name (ENUM: PATIENT, PSYCHOLOGIST, ADMIN)', 'description (TEXT)', 'permissions (JSONB)']
                },
                {
                  table: 'profiles',
                  desc: 'Detail kredensial & bio dokter / pasien',
                  cols: ['id (UUID, PK)', 'user_id (UUID, FK -> users.id, UNIQUE)', 'title (VARCHAR)', 'str_number (VARCHAR)', 'sip_number (VARCHAR)', 'bio (TEXT)', 'specialties (TEXT[])', 'rating (DECIMAL)']
                },
                {
                  table: 'psychologist_schedules',
                  desc: 'Slot ketersediaan waktu dokter',
                  cols: ['id (UUID, PK)', 'psychologist_id (UUID, FK -> users.id)', 'date (DATE)', 'start_time (TIME)', 'end_time (TIME)', 'is_available (BOOLEAN)', 'is_booked (BOOLEAN)']
                },
                {
                  table: 'packages',
                  desc: 'Katalog layanan konsultasi klinik',
                  cols: ['id (UUID, PK)', 'name (VARCHAR)', 'type (ENUM: CHAT, OFFLINE, BUNDLING)', 'duration_minutes (INT)', 'price (BIGINT)', 'benefits (JSONB)', 'is_active (BOOLEAN)']
                },
                {
                  table: 'appointments',
                  desc: 'Pemesanan & reservasi sesi',
                  cols: ['id (UUID, PK)', 'booking_code (VARCHAR, UNIQUE)', 'patient_id (UUID, FK)', 'psychologist_id (UUID, FK)', 'package_id (UUID, FK)', 'schedule_slot_id (UUID, FK)', 'status (ENUM)', 'payment_status (ENUM)']
                },
                {
                  table: 'tests',
                  desc: 'Instrumen asesmen psikologi (DASS-21)',
                  cols: ['id (UUID, PK)', 'code (VARCHAR, UNIQUE)', 'title (VARCHAR)', 'scoring_formula (TEXT)', 'questions (JSONB)', 'is_active (BOOLEAN)']
                },
                {
                  table: 'test_results',
                  desc: 'Hasil pengerjaan kuesioner pasien',
                  cols: ['id (UUID, PK)', 'patient_id (UUID, FK -> users.id)', 'test_id (UUID, FK -> tests.id)', 'total_score (INT)', 'subscale_scores (JSONB)', 'severity_level (ENUM)', 'completed_at']
                },
                {
                  table: 'chats',
                  desc: 'Log percakapan ruang konsultasi privat',
                  cols: ['id (UUID, PK)', 'appointment_id (UUID, FK -> appointments.id)', 'sender_id (UUID, FK -> users.id)', 'message_text (TEXT)', 'sent_at (TIMESTAMP)', 'is_read (BOOLEAN)']
                },
                {
                  table: 'clinical_notes',
                  desc: 'Rekam medis EMR SOAP format',
                  cols: ['id (UUID, PK)', 'appointment_id (UUID, FK, UNIQUE)', 'patient_id (UUID, FK)', 'psychologist_id (UUID, FK)', 'subjective (TEXT)', 'objective (TEXT)', 'assessment (TEXT)', 'plan (TEXT)', 'prognosis (VARCHAR)']
                },
                {
                  table: 'reviews',
                  desc: 'Ulasan & rating pasca-konsultasi',
                  cols: ['id (UUID, PK)', 'appointment_id (UUID, FK, UNIQUE)', 'patient_id (UUID, FK)', 'psychologist_id (UUID, FK)', 'rating (INT, 1-5)', 'comment (TEXT)', 'is_anonymous (BOOLEAN)', 'is_approved (BOOLEAN)']
                }
              ].map(item => (
                <div key={item.table} className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono font-bold text-xs text-indigo-700">{item.table}</span>
                    <span className="text-[10px] text-slate-400 font-semibold">{item.cols.length} Kolom</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mb-3">{item.desc}</p>
                  <ul className="text-[11px] font-mono text-slate-700 space-y-1 bg-white p-2 rounded-xl border border-slate-200">
                    {item.cols.map((c, i) => (
                      <li key={i} className="truncate">• {c}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            {/* SQL DDL Code View */}
            <div className="mt-6">
              <div className="p-4 bg-slate-950 text-slate-200 rounded-2xl font-mono text-xs overflow-x-auto">
                <pre>{`-- SQL DDL Relational Implementation for PostgreSQL
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL CHECK (role IN ('PATIENT', 'PSYCHOLOGIST', 'ADMIN')),
    status VARCHAR(50) DEFAULT 'ACTIVE',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE psychologist_schedules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    psychologist_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    is_available BOOLEAN DEFAULT TRUE,
    is_booked BOOLEAN DEFAULT FALSE,
    CONSTRAINT unique_psychologist_slot UNIQUE (psychologist_id, date, start_time)
);

CREATE TABLE appointments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_code VARCHAR(32) UNIQUE NOT NULL,
    patient_id UUID NOT NULL REFERENCES users(id),
    psychologist_id UUID NOT NULL REFERENCES users(id),
    package_id UUID NOT NULL,
    date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status VARCHAR(50) DEFAULT 'CONFIRMED',
    payment_status VARCHAR(50) DEFAULT 'PAID',
    total_amount NUMERIC(12,2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE clinical_notes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    appointment_id UUID UNIQUE NOT NULL REFERENCES appointments(id),
    patient_id UUID NOT NULL REFERENCES users(id),
    psychologist_id UUID NOT NULL REFERENCES users(id),
    subjective TEXT NOT NULL,
    objective TEXT NOT NULL,
    assessment TEXT NOT NULL,
    plan TEXT NOT NULL,
    prognosis VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);`}</pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: API ENDPOINTS DESIGN */}
      {activeBlueprintTab === 'api' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
            <h3 className="text-xl font-extrabold text-slate-900 mb-1">Daftar Endpoint RESTful & Middleware Authorization</h3>
            <p className="text-xs text-slate-500 mb-6">
              Arsitektur rute API dengan guard middleware `verifyToken`, `requireRole`, dan `verifyAppointmentParticipant`.
            </p>

            <div className="space-y-3">
              {[
                {
                  method: 'GET',
                  endpoint: '/api/v1/public/psychologists',
                  auth: 'Public (Guest)',
                  desc: 'Mengambil daftar profil psikolog terverifikasi, spesialisasi, dan ulasan publik'
                },
                {
                  method: 'GET',
                  endpoint: '/api/v1/public/packages',
                  auth: 'Public (Guest)',
                  desc: 'Mendapatkan katalog paket layanan konsultasi dan tarif aktif'
                },
                {
                  method: 'POST',
                  endpoint: '/api/v1/patient/intake-form',
                  auth: 'requireRole([PATIENT])',
                  desc: 'Menyimpan identitas awal, riwayat medis, dan keluhan sebelum sesi dimulai'
                },
                {
                  method: 'POST',
                  endpoint: '/api/v1/patient/assessments/submit',
                  auth: 'requireRole([PATIENT])',
                  desc: 'Mengirimkan jawaban tes psikologi DASS-21, menghitung skor otomatis, & mengikat ke rekam medis'
                },
                {
                  method: 'POST',
                  endpoint: '/api/v1/appointments/reserve',
                  auth: 'requireRole([PATIENT])',
                  desc: 'Eksekusi booking dengan transaksi locking (mencegah bentrok jadwal/double-booking)'
                },
                {
                  method: 'GET',
                  endpoint: '/api/v1/appointments/:id/chat-history',
                  auth: 'verifyAppointmentParticipant',
                  desc: 'Mengambil riwayat percakapan sesi privat (hanya pasien atau dokter terkait)'
                },
                {
                  method: 'POST',
                  endpoint: '/api/v1/psychologist/schedules/slots',
                  auth: 'requireRole([PSYCHOLOGIST])',
                  desc: 'Membuat atau memperbarui slot ketersediaan waktu praktik dokter'
                },
                {
                  method: 'POST',
                  endpoint: '/api/v1/psychologist/emr/clinical-notes',
                  auth: 'requireRole([PSYCHOLOGIST])',
                  desc: 'Menulis atau memperbarui catatan perkembangan klinis SOAP pasca-sesi'
                },
                {
                  method: 'PATCH',
                  endpoint: '/api/v1/admin/users/:id/verify-status',
                  auth: 'requireRole([ADMIN])',
                  desc: 'Aktivasi akun psikolog baru setelah verifikasi dokumen STR dan SIP'
                },
                {
                  method: 'PATCH',
                  endpoint: '/api/v1/admin/reviews/:id/moderate',
                  auth: 'requireRole([ADMIN])',
                  desc: 'Menyetujui atau menolak ulasan pasien untuk tampil di landing page'
                }
              ].map((route, i) => (
                <div
                  key={i}
                  className="p-4 rounded-2xl border border-slate-200 bg-slate-50/70 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3">
                    <span
                      className={`px-2.5 py-1 rounded-lg font-mono font-extrabold ${
                        route.method === 'GET'
                          ? 'bg-sky-100 text-sky-800'
                          : route.method === 'POST'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {route.method}
                    </span>
                    <span className="font-mono font-bold text-slate-900">{route.endpoint}</span>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <span className="text-slate-600">{route.desc}</span>
                    <span className="px-2.5 py-0.5 rounded-full bg-slate-200 text-slate-800 font-mono font-bold text-[10px] shrink-0">
                      {route.auth}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SECTION 4: KODE KUNCI (CONFLICT LOCK & WEBSOCKET) */}
      {activeBlueprintTab === 'code' && (
        <div className="space-y-6">
          {/* Interactive Concurrency Simulation Box */}
          <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-indigo-900">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 mb-4 gap-4">
              <div>
                <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">Live Race-Condition Simulator</span>
                <h3 className="text-lg font-bold mt-0.5">Pengujian Bentrok Jadwal (Double-Booking Prevention)</h3>
                <p className="text-xs text-slate-400">
                  Simulasikan 2 pasien yang serentak menekan tombol booking pada milidetik yang sama.
                </p>
              </div>

              <button
                onClick={runConcurrencySimulation}
                disabled={simRunning}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl flex items-center gap-2 transition-all shadow-md shadow-indigo-600/30"
              >
                <Play className="w-3.5 h-3.5" />
                <span>{simRunning ? 'Memproses Lock...' : 'Uji Simulasi Race Condition'}</span>
              </button>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl font-mono text-xs text-emerald-400 h-44 overflow-y-auto space-y-1">
              {simLogs.length === 0 ? (
                <div className="text-slate-500 italic">
                  Klik "Uji Simulasi Race Condition" untuk melihat eksekusi transaksi database SERIALIZABLE dengan `SELECT ... FOR UPDATE` lock.
                </div>
              ) : (
                simLogs.map((log, idx) => (
                  <div key={idx} className={log.includes('EXCEPTION') ? 'text-rose-400' : 'text-emerald-400'}>
                    {log}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Key Code 1: Booking Conflict Prevention Implementation */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  1. Logika Pencegahan Bentrok Jadwal (Database Transaction & Row-Level Lock)
                </h3>
                <p className="text-xs text-slate-500">
                  Menggunakan `SELECT ... FOR UPDATE` pada PostgreSQL dengan level isolasi SERIALIZABLE.
                </p>
              </div>
              <button
                onClick={() =>
                  copyToClipboard(
                    `// Production-grade Booking Transaction Handler\nasync function bookAppointmentWithLock(...)`,
                    'code-lock'
                  )
                }
                className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg"
              >
                {copiedSection === 'code-lock' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            <div className="p-4 bg-slate-950 text-slate-200 rounded-2xl font-mono text-xs overflow-x-auto">
              <pre>{`// backend/src/services/appointmentService.ts
import { pool } from '../config/database';
import { ConflictError, NotFoundError } from '../utils/errors';

export async function reserveAppointmentWithConflictLock(params: {
  patientId: string;
  psychologistId: string;
  scheduleSlotId: string;
  packageId: string;
}) {
  const client = await pool.connect();
  try {
    // 1. Mulai Transaksi ACID dengan Isolasi Tinggi
    await client.query('BEGIN ISOLATION LEVEL SERIALIZABLE');

    // 2. Kunci Baris Slot secara Eksklusif (Pessimistic Lock)
    // Query ini mencegah transaksi lain mengubah status slot ini sampai COMMIT/ROLLBACK
    const slotQuery = \`
      SELECT id, psychologist_id, date, start_time, end_time, is_available, is_booked
      FROM psychologist_schedules
      WHERE id = $1
      FOR UPDATE NOWAIT;
    \`;
    const slotResult = await client.query(slotQuery, [params.scheduleSlotId]);

    if (slotResult.rows.length === 0) {
      throw new NotFoundError('Slot waktu tidak ditemukan.');
    }

    const slot = slotResult.rows[0];

    // 3. Validasi Kondisi Bentrok
    if (!slot.is_available || slot.is_booked) {
      throw new ConflictError(
        'Bentrok Jadwal Terdeteksi: Slot waktu ini telah dipesan atau tidak lagi tersedia.'
      );
    }

    // 4. Periksa apakah dokter memiliki janji aktif pada interval waktu yang sama
    const overlapCheck = await client.query(
      \`SELECT id FROM appointments 
       WHERE psychologist_id = $1 AND date = $2 AND start_time = $3 
       AND status IN ('CONFIRMED', 'PENDING', 'IN_PROGRESS')\`,
      [params.psychologistId, slot.date, slot.start_time]
    );

    if (overlapCheck.rows.length > 0) {
      throw new ConflictError('Dokter telah memiliki janji aktif pada jam tersebut.');
    }

    // 5. Buat Record Appointment & Update Status Slot
    const bookingCode = \`JS-\${slot.date.replace(/-/g, '')}-\${Math.floor(1000 + Math.random() * 9000)}\`;
    const newAppointment = await client.query(
      \`INSERT INTO appointments (booking_code, patient_id, psychologist_id, package_id, date, start_time, end_time, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, 'CONFIRMED')
       RETURNING *\`,
      [bookingCode, params.patientId, params.psychologistId, params.packageId, slot.date, slot.start_time, slot.end_time]
    );

    // Kunci slot sehingga tidak bisa dipilih pasien lain
    await client.query(
      'UPDATE psychologist_schedules SET is_booked = TRUE, is_available = FALSE WHERE id = $1',
      [slot.id]
    );

    await client.query('COMMIT');
    return newAppointment.rows[0];
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}`}</pre>
            </div>
          </div>

          {/* Key Code 2: Real-time WebSocket Chat Guard */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  2. Skema Real-Time WebSocket Handler (Pembatasan Akses Pasien & Psikolog)
                </h3>
                <p className="text-xs text-slate-500">
                  Socket.io gateway dengan verifikasi JWT, room authorization, dan countdown session timer.
                </p>
              </div>
              <button
                onClick={() =>
                  copyToClipboard(
                    `// Socket.io Real-time Consultation Chat Gateway\nexport function setupConsultationSocket(...)`,
                    'code-ws'
                  )
                }
                className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg"
              >
                {copiedSection === 'code-ws' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            <div className="p-4 bg-slate-950 text-slate-200 rounded-2xl font-mono text-xs overflow-x-auto">
              <pre>{`// backend/src/websocket/chatSocket.ts
import { Server, Socket } from 'socket.io';
import { verifyJwtToken } from '../utils/auth';
import { db } from '../config/database';

export function registerConsultationSocketServer(io: Server) {
  // 1. Handshake Authentication Middleware
  io.use(async (socket: Socket, next) => {
    try {
      const token = socket.handshake.auth.token;
      if (!token) return next(new Error('Authentication token required'));
      const decoded = await verifyJwtToken(token);
      socket.data.user = decoded; // { id, role, name }
      next();
    } catch (err) {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', (socket: Socket) => {
    const user = socket.data.user;

    // 2. Join Room Event dengan Verifikasi Kepemilikan Sesi
    socket.on('join_consultation_room', async ({ appointmentId }) => {
      // Periksa database: apakah user ini adalah Pasien ATAU Psikolog pada janji temu ini?
      const appointment = await db.appointments.findUnique({
        where: { id: appointmentId }
      });

      if (!appointment) {
        return socket.emit('error', { message: 'Janji temu tidak ditemukan' });
      }

      const isParticipant =
        appointment.patient_id === user.id || appointment.psychologist_id === user.id;

      if (!isParticipant) {
        // Blokir akses pihak ketiga / peretas ruangan
        return socket.emit('error', {
          message: 'Akses Ditolak: Anda bukan peserta yang berhak masuk ke ruang ini.'
        });
      }

      const roomName = \`room_apt_\${appointmentId}\`;
      socket.join(roomName);

      // Beritahu ruang bahwa pengguna telah hadir
      io.to(roomName).emit('user_joined', {
        userId: user.id,
        role: user.role,
        name: user.name,
        timestamp: new Date()
      });
    });

    // 3. Kirim Pesan dengan Enkripsi & Audit Log
    socket.on('send_message', async ({ appointmentId, text }) => {
      const roomName = \`room_apt_\${appointmentId}\`;
      
      // Simpan pesan ke basis data
      const savedMsg = await db.chats.create({
        data: {
          appointment_id: appointmentId,
          sender_id: user.id,
          message_text: text,
          sent_at: new Date()
        }
      });

      io.to(roomName).emit('receive_message', {
        id: savedMsg.id,
        senderId: user.id,
        senderRole: user.role,
        senderName: user.name,
        text,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      });
    });

    // 4. Disconnect & Cleanup
    socket.on('disconnect', () => {
      // Log sesi terputus
    });
  });
}`}</pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
