import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { IntakeForm, Appointment } from '../../types';
import {
  Calendar,
  Clock,
  FileCheck,
  MessageSquare,
  History,
  CheckCircle2,
  AlertCircle,
  Star,
  User,
  ShieldCheck,
  Send,
  Sparkles,
  ChevronRight,
  HelpCircle,
  Activity,
  Award,
  CreditCard,
  QrCode,
  Download,
  Check,
  X,
  RefreshCw,
  Eye
} from 'lucide-react';

export const PatientDashboard: React.FC = () => {
  const {
    currentUser,
    packages,
    psychologists,
    users,
    schedules,
    appointments,
    testResults,
    intakeForms,
    tests,
    chatMessages,
    activePatientTab,
    setActivePatientTab,
    bookAppointment,
    submitIntakeForm,
    submitTestResult,
    sendChatMessage,
    submitReview
  } = useApp();

  const patientId = currentUser?.id || 'user-pat-1';
  const existingIntake = intakeForms[patientId];
  const patientAppointments = appointments.filter(a => a.patientId === patientId);
  const patientTestResults = testResults.filter(r => r.patientId === patientId);

  // Active appointment for live chat (either confirmed or in_progress, or the most recent)
  const activeChatApt =
    patientAppointments.find(a => a.status === 'CONFIRMED' || a.status === 'IN_PROGRESS') ||
    patientAppointments[0];

  // Booking Flow State
  const [selectedPkgId, setSelectedPkgId] = useState<string>(packages[0]?.id || 'pkg-chat-1');
  const [selectedPsychologistId, setSelectedPsychologistId] = useState<string>(psychologists[0]?.userId || 'user-psy-1');
  const [selectedDate, setSelectedDate] = useState<string>('2026-09-16');
  const [selectedSlotId, setSelectedSlotId] = useState<string>('');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('QRIS (BCA / GoPay / OVO)');
  const [bookingSuccessModalApt, setBookingSuccessModalApt] = useState<Appointment | null>(null);

  // Intake Form State
  const [intakeData, setIntakeData] = useState<Partial<IntakeForm>>({
    gender: 'Laki-laki',
    occupation: existingIntake?.occupation || '',
    emergencyContact: existingIntake?.emergencyContact || { name: '', relationship: '', phone: '' },
    primaryConcerns: existingIntake?.primaryConcerns || ['Kecemasan Berlebih (Anxiety)'],
    concernDescription: existingIntake?.concernDescription || '',
    previousTherapy: existingIntake?.previousTherapy || false,
    currentMedications: existingIntake?.currentMedications || 'Tidak ada',
    currentStressLevel: existingIntake?.currentStressLevel || 6,
    sleepQuality: existingIntake?.sleepQuality || 'Cukup',
    suicideRiskFlag: false,
    goals: existingIntake?.goals || ''
  });
  const [intakeSuccess, setIntakeSuccess] = useState(false);

  // Sync intakeData when patientId changes
  useEffect(() => {
    if (existingIntake) {
      setIntakeData({
        gender: existingIntake.gender,
        occupation: existingIntake.occupation,
        emergencyContact: existingIntake.emergencyContact,
        primaryConcerns: existingIntake.primaryConcerns,
        concernDescription: existingIntake.concernDescription,
        previousTherapy: existingIntake.previousTherapy,
        currentMedications: existingIntake.currentMedications,
        currentStressLevel: existingIntake.currentStressLevel,
        sleepQuality: existingIntake.sleepQuality,
        suicideRiskFlag: existingIntake.suicideRiskFlag,
        goals: existingIntake.goals
      });
    } else {
      setIntakeData({
        gender: 'Laki-laki',
        occupation: '',
        emergencyContact: { name: '', relationship: '', phone: '' },
        primaryConcerns: ['Kecemasan Berlebih (Anxiety)'],
        concernDescription: '',
        previousTherapy: false,
        currentMedications: 'Tidak ada',
        currentStressLevel: 5,
        sleepQuality: 'Cukup',
        suicideRiskFlag: false,
        goals: ''
      });
    }
  }, [patientId, existingIntake]);

  // Test Assessment Quiz State (DASS-21)
  const activeTest = tests[0]; // 21 items
  const [testViewMode, setTestViewMode] = useState<'ALL_LIST' | 'STEPPER'>('ALL_LIST');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [testAnswers, setTestAnswers] = useState<Record<number, number>>({});
  const [testCompletedResult, setTestCompletedResult] = useState<any | null>(null);

  // Live Chat State
  const [chatInput, setChatInput] = useState('');
  const [chatTimerMinutes] = useState(48);

  // Review Modal State
  const [reviewModalAptId, setReviewModalAptId] = useState<string | null>(null);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewAnonymous, setReviewAnonymous] = useState(true);

  // Filter slots for selected psychologist and date
  const availableSlots = schedules.filter(
    s => s.psychologistId === selectedPsychologistId && s.date === selectedDate
  );

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSlotId) {
      return;
    }

    const res = bookAppointment({
      patientId,
      patientName: currentUser?.name || 'Pasien',
      patientEmail: currentUser?.email || 'pasien@mail.com',
      psychologistId: selectedPsychologistId,
      packageId: selectedPkgId,
      date: selectedDate,
      slotId: selectedSlotId,
      paymentMethod: selectedPaymentMethod
    });

    if (res.success && res.appointment) {
      setBookingSuccessModalApt(res.appointment);
      setSelectedSlotId('');
    }
  };

  const handleIntakeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitIntakeForm({
      patientId,
      birthDate: '1995-05-14',
      gender: intakeData.gender as any,
      occupation: intakeData.occupation || 'Profesional / Mahasiswa',
      emergencyContact: intakeData.emergencyContact || { name: 'Kerabat Pasien', relationship: 'Keluarga', phone: '0812-9988-7766' },
      primaryConcerns: intakeData.primaryConcerns || ['Kecemasan Berlebih (Anxiety)'],
      concernDescription: intakeData.concernDescription || '',
      previousTherapy: !!intakeData.previousTherapy,
      currentMedications: intakeData.currentMedications || 'Tidak ada',
      currentStressLevel: intakeData.currentStressLevel || 5,
      sleepQuality: intakeData.sleepQuality as any,
      suicideRiskFlag: !!intakeData.suicideRiskFlag,
      goals: intakeData.goals || ''
    });
    setIntakeSuccess(true);
    setTimeout(() => setIntakeSuccess(false), 4000);
  };

  // Auto-fill DASS-21 with realistic answers
  const handleAutoFillDASS21 = () => {
    const dummyAnswers: Record<number, number> = {};
    // Generate realistic clinically interesting scores:
    // Stres: moderate (1-2), Anxiety: moderate-high (2-3), Depresi: mild-moderate (1-2)
    activeTest.questions.forEach((q, idx) => {
      if (q.subscale === 'Kecemasan') {
        dummyAnswers[idx] = [1, 2, 2, 3][idx % 4];
      } else if (q.subscale === 'Stres') {
        dummyAnswers[idx] = [1, 2, 1, 2][idx % 4];
      } else {
        dummyAnswers[idx] = [0, 1, 1, 2][idx % 4];
      }
    });
    setTestAnswers(dummyAnswers);
  };

  const handleAnswerQuestion = (idx: number, score: number) => {
    setTestAnswers(prev => ({ ...prev, [idx]: score }));
  };

  const calculateDASS21Score = () => {
    let total = 0;
    let dep = 0;
    let anx = 0;
    let str = 0;

    activeTest.questions.forEach((q, idx) => {
      const val = testAnswers[idx] ?? 0;
      total += val;
      if (q.subscale === 'Depresi') dep += val;
      if (q.subscale === 'Kecemasan') anx += val;
      if (q.subscale === 'Stres') str += val;
    });

    let severity: 'NORMAL' | 'RINGAN' | 'SEDANG' | 'BERAT' | 'SANGAT_BERAT' = 'NORMAL';
    let interpretation = 'Tingkat stres dan kecemasan Anda berada dalam batas normal dan adaptif.';
    let rec = 'Tetap jaga keseimbangan ritme istirahat dan luangkan waktu untuk kegiatan rekreatif mandiri.';

    if (total >= 28) {
      severity = 'BERAT';
      interpretation = 'Skor total menunjukkan indikasi distres psikologis berat dengan intensitas kecemasan dan stres yang sangat mengganggu fungsi harian.';
      rec = 'Sangat dianjurkan berkonsultasi mendalam dengan psikolog klinis untuk terapi terstruktur (CBT) dan psikoedukasi regulasi sistem saraf.';
    } else if (total >= 18) {
      severity = 'SEDANG';
      interpretation = 'Indikasi tingkat kecemasan dan beban stres berada pada derajat Sedang. Terdapat keluhan psikosomatis atau ketegangan pikiran berlebih.';
      rec = 'Disarankan mengikuti sesi konseling 1-on-1 untuk melatih teknik pernapasan diafragma 4-7-8 dan restrukturisasi pikiran cemas.';
    } else if (total >= 10) {
      severity = 'RINGAN';
      interpretation = 'Indikasi gejala kecemasan atau stres ringan yang muncul sesekali pada situasi pemicu tertentu.';
      rec = 'Dapat dibantu dengan latihan mindfulness teratur, perbaikan sleep hygiene, dan manajemen beban kerja harian.';
    }

    const saved = submitTestResult({
      patientId,
      patientName: currentUser?.name || 'Pasien',
      testId: activeTest.id,
      testCode: activeTest.code,
      testTitle: activeTest.title,
      totalScore: total,
      subscaleScores: {
        depression: dep,
        anxiety: anx,
        stress: str
      },
      severityLevel: severity,
      interpretation,
      clinicalRecommendation: rec
    });

    setTestCompletedResult(saved);
  };

  const answeredCount = Object.keys(testAnswers).length;
  const isAllAnswered = answeredCount === activeTest.questions.length;

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !activeChatApt) return;
    sendChatMessage(activeChatApt.id, chatInput);
    setChatInput('');
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewModalAptId) return;
    const targetApt = appointments.find(a => a.id === reviewModalAptId);
    if (!targetApt) return;

    submitReview({
      appointmentId: reviewModalAptId,
      psychologistId: targetApt.psychologistId,
      rating: reviewRating,
      comment: reviewComment,
      isAnonymous: reviewAnonymous
    });

    setReviewModalAptId(null);
    setReviewComment('');
  };

  const currentMessages = activeChatApt ? chatMessages[activeChatApt.id] || [] : [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Patient Header Card */}
      <div className="bg-emerald-900 text-white rounded-3xl p-6 sm:p-8 shadow-sm relative overflow-hidden mb-6">
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-emerald-700/30 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <img
              src={currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
              alt={currentUser?.name}
              className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-400/40 shadow-sm"
            />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-800 text-emerald-200 border border-emerald-700">
                  Portal Pasien (Klien)
                </span>
                <span className="text-xs text-emerald-300 font-mono">ID: #{patientId}</span>
              </div>
              <h2 className="text-2xl font-black mt-1 tracking-tight">{currentUser?.name}</h2>
              <p className="text-xs text-emerald-200 mt-0.5">
                {currentUser?.email} • Keluhan Utama: {existingIntake?.primaryConcerns?.[0] || 'Anxiety & Workplace Burnout'}
              </p>
            </div>
          </div>

          {/* Quick Action Navigation Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => setActivePatientTab('booking')}
              className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-bold rounded-xl text-xs flex items-center gap-2 transition-all shadow-sm"
            >
              <Calendar className="w-4 h-4" />
              Booking Konsultasi
            </button>
            <button
              onClick={() => setActivePatientTab('tests')}
              className="px-4 py-2.5 bg-emerald-800/80 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs border border-emerald-700 flex items-center gap-2 transition-all"
            >
              <FileCheck className="w-4 h-4 text-emerald-300" />
              Tes Mandiri DASS-21
            </button>
            {activeChatApt && (
              <button
                onClick={() => setActivePatientTab('chat')}
                className="px-4 py-2.5 bg-white text-emerald-950 hover:bg-emerald-50 font-bold rounded-xl text-xs flex items-center gap-2 transition-all shadow-sm"
              >
                <MessageSquare className="w-4 h-4 text-emerald-700" />
                Ruang Chat Sesi
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Tabs Navigation Bar */}
      <div className="flex items-center gap-1 border-b border-slate-200 overflow-x-auto pb-px mb-6">
        {[
          { id: 'overview', label: 'Ringkasan Pasien', icon: Activity },
          { id: 'booking', label: 'Booking Jadwal Konsultasi', icon: Calendar },
          { id: 'tests', label: 'Asesmen DASS-21 Interaktif', icon: FileCheck },
          { id: 'intake', label: 'Formulir Intake Klinis', icon: User },
          { id: 'chat', label: 'Ruang Chat Konsultasi', icon: MessageSquare },
          { id: 'history', label: 'Riwayat & Ulasan Sesi', icon: History }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activePatientTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActivePatientTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-3 border-b-2 text-xs font-bold whitespace-nowrap transition-all ${
                isActive
                  ? 'border-emerald-600 text-emerald-700 bg-emerald-50/50'
                  : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-600' : 'text-slate-400'}`} />
              {tab.label}
              {tab.id === 'history' && patientAppointments.length > 0 && (
                <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-slate-100 text-slate-700 font-bold">
                  {patientAppointments.length}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW */}
      {activePatientTab === 'overview' && (
        <div className="space-y-6">
          {/* Status Quick Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Status Intake Form</span>
                <User className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-lg font-extrabold text-slate-900 flex items-center gap-1.5">
                {existingIntake ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <span>Lengkap & Terisi</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-5 h-5 text-amber-500" />
                    <span>Belum Diisi</span>
                  </>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-1">
                {existingIntake ? `Tersimpan pada ${existingIntake.completedAt}` : 'Harap diisi sebelum sesi konseling.'}
              </p>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Hasil DASS-21 Terakhir</span>
                <Activity className="w-4 h-4 text-teal-600" />
              </div>
              <div className="text-lg font-extrabold text-slate-900">
                {patientTestResults.length > 0 ? (
                  <span className="inline-flex items-center gap-1.5 text-teal-800">
                    <span className="px-2 py-0.5 rounded bg-teal-100 text-xs font-black">
                      {patientTestResults[0].severityLevel}
                    </span>
                    <span>(Skor {patientTestResults[0].totalScore})</span>
                  </span>
                ) : (
                  <span className="text-slate-400 text-sm font-semibold">Belum pernah tes</span>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-1">
                {patientTestResults.length > 0
                  ? `Evaluasi: Kecemasan ${patientTestResults[0].subscaleScores.anxiety}, Stres ${patientTestResults[0].subscaleScores.stress}`
                  : 'Ikuti tes mandiri 5 menit untuk mengetahui skor.'}
              </p>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Sesi Aktif Mendatang</span>
                <Clock className="w-4 h-4 text-indigo-600" />
              </div>
              <div className="text-lg font-extrabold text-slate-900">
                {activeChatApt ? `${activeChatApt.date}` : 'Tidak Ada'}
              </div>
              <p className="text-xs text-slate-500 mt-1">
                {activeChatApt
                  ? `${activeChatApt.startTime} - ${activeChatApt.endTime} WIB (${activeChatApt.packageType})`
                  : 'Pesan jadwal konseling untuk mulai berkonsultasi.'}
              </p>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Tingkat Stres Mandiri</span>
                <Sparkles className="w-4 h-4 text-amber-500" />
              </div>
              <div className="text-lg font-extrabold text-slate-900">
                {existingIntake ? `${existingIntake.currentStressLevel} / 10` : 'Belum tercatat'}
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Kualitas Tidur: {existingIntake?.sleepQuality || 'Normal'}
              </p>
            </div>
          </div>

          {/* Active Appointment Live Banner if Confirmed */}
          {activeChatApt && (
            <div className="bg-gradient-to-r from-teal-50 to-emerald-50 border border-teal-200 rounded-3xl p-6 sm:p-7 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-600 text-white flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                    Jadwal Terkonfirmasi
                  </span>
                  <span className="text-xs font-mono text-slate-500">#{activeChatApt.bookingCode}</span>
                </div>
                <h3 className="text-xl font-black text-slate-900 mt-1">
                  {activeChatApt.packageName} dengan {activeChatApt.psychologistName}
                </h3>
                <p className="text-xs text-slate-600">
                  Tanggal: <strong>{activeChatApt.date}</strong> pukul <strong>{activeChatApt.startTime} - {activeChatApt.endTime} WIB</strong> • Lokasi: {activeChatApt.meetingLocation}
                </p>
              </div>

              <div className="flex items-center gap-3 w-full md:w-auto">
                <button
                  onClick={() => setActivePatientTab('chat')}
                  className="flex-1 md:flex-initial px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all"
                >
                  <MessageSquare className="w-4 h-4" />
                  Buka Ruang Konsultasi Chat
                </button>
              </div>
            </div>
          )}

          {/* Patient Medical File Summary */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left: Intake summary */}
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h4 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <User className="w-4 h-4 text-emerald-600" />
                  Rekam Medis & Riwayat Pasien
                </h4>
                <button
                  onClick={() => setActivePatientTab('intake')}
                  className="text-xs font-bold text-emerald-600 hover:underline"
                >
                  Edit Formulir
                </button>
              </div>

              {existingIntake ? (
                <div className="space-y-3 text-xs">
                  <div>
                    <span className="text-slate-400 font-bold block mb-1">KELUHAN UTAMA</span>
                    <div className="flex flex-wrap gap-1.5">
                      {existingIntake.primaryConcerns.map((c, i) => (
                        <span key={i} className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 font-semibold border border-emerald-100">
                          {c}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-slate-400 font-bold block mb-0.5">DESKRIPSI KELUHAN</span>
                    <p className="text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                      "{existingIntake.concernDescription}"
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <span className="text-slate-400 block text-[10px] font-bold">PEKERJAAN</span>
                      <span className="font-bold text-slate-800">{existingIntake.occupation}</span>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <span className="text-slate-400 block text-[10px] font-bold">KONTAK DARURAT</span>
                      <span className="font-bold text-slate-800">{existingIntake.emergencyContact.name} ({existingIntake.emergencyContact.phone})</span>
                    </div>
                  </div>

                  <div>
                    <span className="text-slate-400 font-bold block mb-0.5">TUJUAN SESI</span>
                    <p className="text-slate-600 italic">"{existingIntake.goals}"</p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-xs text-slate-500 mb-3">Formulir intake belum dilengkapi.</p>
                  <button
                    onClick={() => setActivePatientTab('intake')}
                    className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold"
                  >
                    Isi Intake Form Sekarang
                  </button>
                </div>
              )}
            </div>

            {/* Right: DASS-21 Graph & Subscale Breakdown */}
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h4 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-teal-600" />
                  Grafik Skor Asesmen DASS-21
                </h4>
                <button
                  onClick={() => setActivePatientTab('tests')}
                  className="text-xs font-bold text-teal-600 hover:underline"
                >
                  Tes Ulang
                </button>
              </div>

              {patientTestResults.length > 0 ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Derajat Keparahan</span>
                      <div className="text-sm font-extrabold text-slate-900">
                        {patientTestResults[0].severityLevel} (Skor Total: {patientTestResults[0].totalScore})
                      </div>
                    </div>
                    <span className="text-xs text-slate-400">{patientTestResults[0].completedAt}</span>
                  </div>

                  {/* Subscale Progress Meters */}
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-xs font-bold mb-1">
                        <span className="text-rose-700">Subskala Depresi</span>
                        <span className="text-rose-900">{patientTestResults[0].subscaleScores.depression} / 21</span>
                      </div>
                      <div className="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-rose-500 rounded-full"
                          style={{ width: `${Math.min(100, (patientTestResults[0].subscaleScores.depression / 21) * 100)}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-bold mb-1">
                        <span className="text-amber-700">Subskala Kecemasan (Anxiety)</span>
                        <span className="text-amber-900">{patientTestResults[0].subscaleScores.anxiety} / 21</span>
                      </div>
                      <div className="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-500 rounded-full"
                          style={{ width: `${Math.min(100, (patientTestResults[0].subscaleScores.anxiety / 21) * 100)}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-bold mb-1">
                        <span className="text-teal-700">Subskala Stres</span>
                        <span className="text-teal-900">{patientTestResults[0].subscaleScores.stress} / 21</span>
                      </div>
                      <div className="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-teal-500 rounded-full"
                          style={{ width: `${Math.min(100, (patientTestResults[0].subscaleScores.stress / 21) * 100)}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-teal-50/70 border border-teal-100 rounded-xl text-xs text-teal-900 leading-relaxed">
                    <strong>Rekomendasi Terapi:</strong> {patientTestResults[0].clinicalRecommendation}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-xs text-slate-500 mb-3">Belum ada riwayat tes DASS-21.</p>
                  <button
                    onClick={() => setActivePatientTab('tests')}
                    className="px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold"
                  >
                    Mulai Tes DASS-21 Sekarang
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: BOOKING JADWAL */}
      {activePatientTab === 'booking' && (
        <div className="py-6 max-w-4xl mx-auto space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
            <div className="mb-6 pb-4 border-b border-slate-100">
              <div className="text-xs font-bold text-emerald-600 uppercase tracking-wider">Sistem Reservasi & Transaksi</div>
              <h3 className="text-2xl font-extrabold text-slate-900 mt-1">Booking Jadwal Konsultasi Psikologi</h3>
              <p className="text-xs text-slate-500 mt-1">
                Pilih paket, psikolog, tanggal, dan slot jam. Sistem dilengkapi proteksi bentrok jadwal (concurrency lock).
              </p>
            </div>

            <form onSubmit={handleBookingSubmit} className="space-y-6">
              {/* Step 1: Choose Package */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  1. Pilih Jenis Paket Konsultasi
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {packages.map(pkg => (
                    <div
                      key={pkg.id}
                      onClick={() => setSelectedPkgId(pkg.id)}
                      className={`p-4 rounded-2xl border cursor-pointer transition-all relative ${
                        selectedPkgId === pkg.id
                          ? 'border-emerald-600 bg-emerald-50/70 ring-1 ring-emerald-600'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                        {pkg.badge}
                      </span>
                      <div className="text-sm font-bold text-slate-900 mt-2">{pkg.name}</div>
                      <div className="text-xs text-slate-500 mt-1">{pkg.durationMinutes} Menit Sesi</div>
                      <div className="text-base font-black text-emerald-700 mt-2">
                        Rp {pkg.price.toLocaleString('id-ID')}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Step 2: Choose Psychologist */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  2. Pilih Psikolog Berizin
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {psychologists.map(psy => {
                    const u = users.find(user => user.id === psy.userId);
                    return (
                      <div
                        key={psy.userId}
                        onClick={() => {
                          setSelectedPsychologistId(psy.userId);
                          setSelectedSlotId('');
                        }}
                        className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center gap-3 ${
                          selectedPsychologistId === psy.userId
                            ? 'border-emerald-600 bg-emerald-50/70 ring-1 ring-emerald-600'
                            : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <img src={u?.avatar} alt={u?.name} className="w-12 h-12 rounded-xl object-cover" />
                        <div>
                          <div className="text-xs font-bold text-slate-900 leading-snug">{u?.name}</div>
                          <div className="text-[11px] text-emerald-700 font-medium">{psy.title}</div>
                          <div className="text-[10px] text-slate-400 mt-0.5">Rating {psy.rating} ★ • {psy.experienceYears} Tahun Praktik</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Step 3: Choose Date */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  3. Pilih Tanggal Konsultasi
                </label>
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {['2026-09-16', '2026-09-17', '2026-09-18', '2026-09-19'].map(d => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => {
                        setSelectedDate(d);
                        setSelectedSlotId('');
                      }}
                      className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
                        selectedDate === d
                          ? 'bg-slate-900 text-white'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {d === '2026-09-16' ? 'Hari Ini (16 Sep)' : d === '2026-09-17' ? 'Besok (17 Sep)' : d}
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 4: Choose Slot with Realtime Availability Check */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    4. Pilih Jam Konsultasi (Slot Waktu)
                  </label>
                  <span className="text-[11px] text-slate-400">Zona Waktu: WIB (Jakarta)</span>
                </div>

                {availableSlots.length === 0 ? (
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-500 text-center">
                    Tidak ada slot yang tersedia pada tanggal ini untuk psikolog yang dipilih. Silakan pilih tanggal lain.
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {availableSlots.map(slot => {
                      const isUnavailable = !slot.isAvailable || slot.isBooked;
                      return (
                        <button
                          key={slot.id}
                          type="button"
                          disabled={isUnavailable}
                          onClick={() => setSelectedSlotId(slot.id)}
                          className={`p-3 rounded-xl text-xs font-bold border transition-all text-center relative ${
                            selectedSlotId === slot.id
                              ? 'border-emerald-600 bg-emerald-600 text-white shadow-xs'
                              : isUnavailable
                              ? 'border-slate-200 bg-slate-100 text-slate-400 cursor-not-allowed line-through'
                              : 'border-slate-200 bg-white text-slate-800 hover:border-emerald-400'
                          }`}
                        >
                          <div>
                            {slot.startTime} - {slot.endTime}
                          </div>
                          <div className="text-[10px] font-normal mt-0.5">
                            {isUnavailable ? 'Sudah Terisi' : 'Tersedia'}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Step 5: Choose Payment Method */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  5. Metode Pembayaran (Simulasi Instan)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    { id: 'QRIS (BCA / GoPay / OVO)', icon: QrCode, desc: 'Scan QRIS Instan' },
                    { id: 'Virtual Account BCA', icon: CreditCard, desc: 'Otomatis Terverifikasi' },
                    { id: 'Virtual Account Mandiri', icon: CreditCard, desc: 'Konfirmasi 1 Detik' }
                  ].map(m => {
                    const MIcon = m.icon;
                    return (
                      <div
                        key={m.id}
                        onClick={() => setSelectedPaymentMethod(m.id)}
                        className={`p-3 rounded-xl border cursor-pointer flex items-center gap-3 transition-all ${
                          selectedPaymentMethod === m.id
                            ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-bold ring-1 ring-emerald-600'
                            : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <MIcon className="w-5 h-5 text-emerald-600" />
                        <div>
                          <div className="text-xs font-bold">{m.id}</div>
                          <div className="text-[10px] text-slate-500">{m.desc}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Submit Reservation */}
              <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-[11px] text-slate-400 block">Total Biaya Konsultasi</span>
                  <span className="text-xl font-extrabold text-slate-900">
                    Rp {packages.find(p => p.id === selectedPkgId)?.price.toLocaleString('id-ID')}
                  </span>
                </div>
                <button
                  type="submit"
                  disabled={!selectedSlotId}
                  className={`px-7 py-3.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 ${
                    selectedSlotId
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4" />
                  Konfirmasi Booking & Kunci Jadwal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* E-TICKET BOOKING CONFIRMATION MODAL */}
      {bookingSuccessModalApt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative overflow-hidden">
            <div className="text-center pb-4 border-b border-slate-100">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center mx-auto mb-3">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                Reservasi Berhasil & Terverifikasi
              </span>
              <h3 className="text-2xl font-black text-slate-900 mt-2">E-Ticket Konsultasi JiwaSehat</h3>
              <p className="text-xs text-slate-500 mt-0.5">Kode Tiket: <strong>{bookingSuccessModalApt.bookingCode}</strong></p>
            </div>

            <div className="py-4 space-y-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5">
                <div className="flex justify-between text-slate-600">
                  <span>Nama Pasien:</span>
                  <strong className="text-slate-900">{bookingSuccessModalApt.patientName}</strong>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Psikolog Pendamping:</span>
                  <strong className="text-slate-900">{bookingSuccessModalApt.psychologistName}</strong>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Jadwal Sesi:</span>
                  <strong className="text-emerald-800 font-bold">{bookingSuccessModalApt.date} • {bookingSuccessModalApt.startTime} - {bookingSuccessModalApt.endTime} WIB</strong>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Jenis Layanan:</span>
                  <strong className="text-slate-900">{bookingSuccessModalApt.packageName}</strong>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Ruang Konsultasi:</span>
                  <strong className="text-indigo-700 font-mono">{bookingSuccessModalApt.meetingLocation}</strong>
                </div>
                <div className="flex justify-between text-slate-600 pt-1 border-t border-slate-200">
                  <span>Status Pembayaran:</span>
                  <span className="text-emerald-700 font-black">LUNAS (Terverifikasi)</span>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-[11px] text-emerald-900">
                <ShieldCheck className="w-5 h-5 text-emerald-700 flex-shrink-0" />
                <span>Slot waktu telah dikunci eksklusif untuk Anda. Rekam medis dan ruang chat terenkripsi telah aktif.</span>
              </div>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center gap-2">
              <button
                onClick={() => {
                  setBookingSuccessModalApt(null);
                  setActivePatientTab('chat');
                }}
                className="w-full sm:flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-xs"
              >
                <MessageSquare className="w-4 h-4" />
                Buka Ruang Chat Sekarang
              </button>
              <button
                onClick={() => {
                  setBookingSuccessModalApt(null);
                  setActivePatientTab('history');
                }}
                className="w-full sm:w-auto px-5 py-3 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition-colors"
              >
                Lihat di Riwayat
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: INTAKE FORM */}
      {activePatientTab === 'intake' && (
        <div className="py-6 max-w-3xl mx-auto">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
            <div className="mb-6 pb-4 border-b border-slate-100">
              <div className="text-xs font-bold text-emerald-600 uppercase tracking-wider">Kerahasiaan Medis Terjamin HIMPSI</div>
              <h3 className="text-2xl font-extrabold text-slate-900 mt-1">Form Identitas & Keluhan Awal (Intake Form)</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Informasi ini tersimpan aman di EMR klinis dan hanya dapat dibaca oleh Psikolog yang mendampingi sesi Anda.
              </p>
            </div>

            {intakeSuccess && (
              <div className="p-4 rounded-2xl mb-6 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-medium flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Form Intake berhasil diperbarui dan disinkronkan ke rekam medis Anda.
              </div>
            )}

            <form onSubmit={handleIntakeSubmit} className="space-y-6">
              {/* Identitas */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Nama Pasien</label>
                  <input
                    type="text"
                    disabled
                    value={currentUser?.name || ''}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Pekerjaan / Profesi</label>
                  <input
                    type="text"
                    required
                    value={intakeData.occupation}
                    onChange={e => setIntakeData({ ...intakeData, occupation: e.target.value })}
                    placeholder="Contoh: Software Engineer / Desainer"
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Kontak Darurat */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Kontak Darurat (Keluarga / Kerabat Terdekat)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <input
                    type="text"
                    placeholder="Nama Kerabat"
                    value={intakeData.emergencyContact?.name}
                    onChange={e =>
                      setIntakeData({
                        ...intakeData,
                        emergencyContact: { ...intakeData.emergencyContact!, name: e.target.value }
                      })
                    }
                    className="px-3 py-2.5 rounded-xl border border-slate-200 text-xs"
                  />
                  <input
                    type="text"
                    placeholder="Hubungan (Misal: Pasangan/Ibu)"
                    value={intakeData.emergencyContact?.relationship}
                    onChange={e =>
                      setIntakeData({
                        ...intakeData,
                        emergencyContact: { ...intakeData.emergencyContact!, relationship: e.target.value }
                      })
                    }
                    className="px-3 py-2.5 rounded-xl border border-slate-200 text-xs"
                  />
                  <input
                    type="text"
                    placeholder="No. Telepon"
                    value={intakeData.emergencyContact?.phone}
                    onChange={e =>
                      setIntakeData({
                        ...intakeData,
                        emergencyContact: { ...intakeData.emergencyContact!, phone: e.target.value }
                      })
                    }
                    className="px-3 py-2.5 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
              </div>

              {/* Keluhan Utama */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">Keluhan Utama yang Dirasakan</label>
                <div className="flex flex-wrap gap-2">
                  {[
                    'Kecemasan Berlebih (Anxiety)',
                    'Burnout Pekerjaan',
                    'Sulit Tidur / Insomnia',
                    'Depresi & Rasa Hampa',
                    'Serangan Panik Pagi Hari',
                    'Masalah Hubungan Asmara / Keluarga',
                    'Krisis Percaya Diri (Self-Esteem)',
                    'Trauma Masa Lalu'
                  ].map(concern => {
                    const isSelected = intakeData.primaryConcerns?.includes(concern);
                    return (
                      <button
                        type="button"
                        key={concern}
                        onClick={() => {
                          const list = intakeData.primaryConcerns || [];
                          if (isSelected) {
                            setIntakeData({ ...intakeData, primaryConcerns: list.filter(c => c !== concern) });
                          } else {
                            setIntakeData({ ...intakeData, primaryConcerns: [...list, concern] });
                          }
                        }}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                          isSelected
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {concern}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Deskripsi Keluhan */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Deskripsikan Apa yang Sedang Dialami (Bebas)
                </label>
                <textarea
                  rows={4}
                  value={intakeData.concernDescription}
                  onChange={e => setIntakeData({ ...intakeData, concernDescription: e.target.value })}
                  placeholder="Sejak kapan keluhan ini mengganggu Anda? Apa pemicu utama yang Anda rasakan? Apa respons fisik tubuh Anda?"
                  className="w-full p-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              {/* Skala Stres & Kualitas Tidur */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                <div>
                  <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                    <span>Skala Stres Saat Ini</span>
                    <span className="text-emerald-700 font-extrabold">{intakeData.currentStressLevel} / 10</span>
                  </div>
                  <input
                    type="range"
                    min={1}
                    max={10}
                    value={intakeData.currentStressLevel}
                    onChange={e => setIntakeData({ ...intakeData, currentStressLevel: Number(e.target.value) })}
                    className="w-full accent-emerald-600"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                    <span>1 (Sangat Tenang)</span>
                    <span>10 (Kewalahan Hebat)</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Kualitas Tidur 1 Minggu Terakhir</label>
                  <select
                    value={intakeData.sleepQuality}
                    onChange={e => setIntakeData({ ...intakeData, sleepQuality: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-white"
                  >
                    <option value="Baik">Baik (Nyenyak 7-8 jam)</option>
                    <option value="Cukup">Cukup (Kadang terbangun)</option>
                    <option value="Buruk">Buruk (Sulit tidur / sering terbangun)</option>
                    <option value="Insomnia Akut">Insomnia Akut (Hanya tidur 2-3 jam)</option>
                  </select>
                </div>
              </div>

              {/* Riwayat Terapi & Obat */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Pernah Konseling Sebelumnya?</label>
                  <div className="flex gap-3">
                    <label className="flex items-center gap-1.5 text-xs text-slate-700">
                      <input
                        type="radio"
                        checked={intakeData.previousTherapy === true}
                        onChange={() => setIntakeData({ ...intakeData, previousTherapy: true })}
                        className="accent-emerald-600"
                      />
                      Pernah
                    </label>
                    <label className="flex items-center gap-1.5 text-xs text-slate-700">
                      <input
                        type="radio"
                        checked={intakeData.previousTherapy === false}
                        onChange={() => setIntakeData({ ...intakeData, previousTherapy: false })}
                        className="accent-emerald-600"
                      />
                      Ini Pengalaman Pertama
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Obat yang Sedang Dikonsumsi</label>
                  <input
                    type="text"
                    value={intakeData.currentMedications}
                    onChange={e => setIntakeData({ ...intakeData, currentMedications: e.target.value })}
                    placeholder="Contoh: Tidak ada / Vitamin B kompleks"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
              </div>

              {/* Harapan Terapi */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Harapan & Tujuan dari Sesi Ini</label>
                <input
                  type="text"
                  value={intakeData.goals}
                  onChange={e => setIntakeData({ ...intakeData, goals: e.target.value })}
                  placeholder="Misal: Ingin menemukan strategi mengendalikan panik saat presentasi kerja..."
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs"
                />
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Simpan Form Intake Pasien
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TAB 4: ONLINE PSYCHOLOGICAL ASSESSMENT (DASS-21) */}
      {activePatientTab === 'tests' && (
        <div className="py-6 max-w-4xl mx-auto space-y-6">
          {/* Top Test Banner with Auto-fill Demo */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold px-2 py-0.5 rounded bg-teal-100 text-teal-800 font-mono">
                    {activeTest.code}
                  </span>
                  <span className="text-xs text-slate-400 font-bold">21 Butir Pertanyaan Klinis</span>
                </div>
                <h3 className="text-2xl font-black text-slate-900 mt-1">{activeTest.title}</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-2xl">
                  {activeTest.shortDescription} Pilihlah salah satu opsi (0 sampai 3) yang paling menggambarkan kondisi Anda selama 1 pekan terakhir.
                </p>
              </div>

              {/* DEMO AUTO-FILL BUTTON */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <button
                  type="button"
                  onClick={handleAutoFillDASS21}
                  className="px-4 py-2.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all shadow-xs"
                  title="Klik untuk mengisi otomatis seluruh 21 pertanyaan dengan data realistis untuk pengujian cepat"
                >
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span>Isi Otomatis (Auto-fill Demo)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setTestViewMode(testViewMode === 'ALL_LIST' ? 'STEPPER' : 'ALL_LIST')}
                  className="px-3 py-2.5 border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold text-xs rounded-xl"
                >
                  {testViewMode === 'ALL_LIST' ? 'Mode Stepper' : 'Mode Semua Soal'}
                </button>
              </div>
            </div>

            {/* Progress Bar & Answer Status */}
            <div className="py-4 border-b border-slate-100 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-700">
                Status Pengisian: <strong className="text-teal-700">{answeredCount} / {activeTest.questions.length} Terjawab</strong>
              </span>
              <span className="text-slate-400">
                Skala Nilai: 0 (Tidak Pernah) s/d 3 (Hampir Selalu)
              </span>
            </div>

            <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden my-4">
              <div
                className="bg-teal-600 h-full transition-all duration-300 rounded-full"
                style={{ width: `${(answeredCount / activeTest.questions.length) * 100}%` }}
              />
            </div>

            {/* Questions Rendering (ALL LIST MODE) */}
            {testViewMode === 'ALL_LIST' ? (
              <div className="space-y-4 my-6">
                {activeTest.questions.map((q, qIndex) => {
                  const currentSelected = testAnswers[qIndex];
                  return (
                    <div
                      key={q.id}
                      className={`p-4 rounded-2xl border transition-all ${
                        currentSelected !== undefined
                          ? 'border-teal-200 bg-teal-50/30'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <span className="text-xs font-bold text-slate-800">
                          {qIndex + 1}. {q.text}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            q.subscale === 'Depresi'
                              ? 'bg-rose-50 text-rose-700'
                              : q.subscale === 'Kecemasan'
                              ? 'bg-amber-50 text-amber-700'
                              : 'bg-teal-50 text-teal-700'
                          }`}
                        >
                          {q.subscale}
                        </span>
                      </div>

                      {/* 4 Radio Option Buttons */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                        {q.options.map(opt => {
                          const isPicked = currentSelected === opt.score;
                          return (
                            <button
                              key={opt.score}
                              type="button"
                              onClick={() => handleAnswerQuestion(qIndex, opt.score)}
                              className={`p-2.5 rounded-xl text-xs font-semibold border text-left flex items-center justify-between transition-all ${
                                isPicked
                                  ? 'bg-teal-700 text-white border-teal-700 shadow-xs'
                                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                              }`}
                            >
                              <span>{opt.label}</span>
                              <span
                                className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                                  isPicked ? 'bg-white text-teal-800' : 'bg-slate-100 text-slate-500'
                                }`}
                              >
                                {opt.score}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              /* STEPPER MODE */
              <div className="my-6 space-y-6">
                <div className="p-6 bg-teal-50/60 rounded-2xl border border-teal-100">
                  <span className="inline-block px-2 py-0.5 rounded bg-teal-100 text-teal-800 text-[10px] font-bold uppercase mb-2">
                    Kategori: {activeTest.questions[currentQuestionIndex].subscale}
                  </span>
                  <p className="text-lg font-bold text-slate-900 leading-relaxed">
                    "{activeTest.questions[currentQuestionIndex].text}"
                  </p>
                </div>

                <div className="space-y-2.5">
                  {activeTest.questions[currentQuestionIndex].options.map(opt => (
                    <button
                      key={opt.score}
                      onClick={() => {
                        handleAnswerQuestion(currentQuestionIndex, opt.score);
                        if (currentQuestionIndex < activeTest.questions.length - 1) {
                          setCurrentQuestionIndex(prev => prev + 1);
                        }
                      }}
                      className="w-full p-4 text-left rounded-2xl border border-slate-200 hover:border-teal-500 hover:bg-teal-50/50 text-xs sm:text-sm font-semibold text-slate-800 transition-all flex items-center justify-between"
                    >
                      <span>{opt.label}</span>
                      <span className="w-6 h-6 rounded-full border border-slate-300 flex items-center justify-center text-xs font-bold">
                        {opt.score}
                      </span>
                    </button>
                  ))}
                </div>

                <div className="flex justify-between items-center pt-4">
                  <button
                    disabled={currentQuestionIndex === 0}
                    onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
                    className="px-4 py-2 border rounded-xl text-xs font-semibold disabled:opacity-30"
                  >
                    Sebelumnya
                  </button>
                  <button
                    disabled={currentQuestionIndex === activeTest.questions.length - 1}
                    onClick={() => setCurrentQuestionIndex(prev => Math.min(activeTest.questions.length - 1, prev + 1))}
                    className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-semibold disabled:opacity-30"
                  >
                    Selanjutnya
                  </button>
                </div>
              </div>
            )}

            {/* Bottom Calculate Button */}
            <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="text-xs text-slate-500">
                {isAllAnswered ? (
                  <span className="text-emerald-700 font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    Seluruh 21 pertanyaan sudah lengkap terisi!
                  </span>
                ) : (
                  <span>Lengkapi atau klik <strong>"Isi Otomatis"</strong> untuk langsung menghitung.</span>
                )}
              </div>

              <button
                type="button"
                onClick={calculateDASS21Score}
                className="px-8 py-3.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Activity className="w-4 h-4" />
                Hitung Skor & Simpan Hasil Evaluasi (DASS-21)
              </button>
            </div>
          </div>

          {/* EVALUATION RESULT MODAL */}
          {testCompletedResult && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 animate-in fade-in duration-150">
              <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative overflow-hidden">
                <div className="text-center pb-4 border-b border-slate-100">
                  <div className="w-14 h-14 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center mx-auto mb-3 shadow-xs">
                    <Award className="w-8 h-8" />
                  </div>
                  <span className="text-xs font-bold text-teal-600 uppercase tracking-wider bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
                    Hasil Asesmen DASS-21 Tersimpan
                  </span>
                  <h3 className="text-2xl font-black text-slate-900 mt-2">Psikogram Klinis Mandiri</h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Evaluasi terikat ke akun <strong>{testCompletedResult.patientName}</strong> dan otomatis terlihat oleh psikolog saat sesi konsultasi.
                  </p>
                </div>

                <div className="py-4 space-y-4 text-xs">
                  {/* Total score & severity */}
                  <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Tingkat Derajat Keparahan</span>
                      <div className="text-xl font-black text-slate-900 mt-0.5 flex items-center gap-2">
                        <span className={`px-2.5 py-0.5 rounded text-xs font-black ${
                          testCompletedResult.severityLevel === 'BERAT' || testCompletedResult.severityLevel === 'SANGAT_BERAT'
                            ? 'bg-rose-100 text-rose-800'
                            : testCompletedResult.severityLevel === 'SEDANG'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          KATEGORI {testCompletedResult.severityLevel}
                        </span>
                      </div>
                    </div>
                    <div className="text-center px-4 py-2 bg-white rounded-xl border border-slate-200 shadow-xs">
                      <span className="text-[10px] text-slate-400 uppercase font-bold">Total Skor</span>
                      <div className="text-2xl font-black text-teal-700">{testCompletedResult.totalScore}</div>
                    </div>
                  </div>

                  {/* Subscales Breakdown */}
                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div className="p-3 bg-rose-50 rounded-xl border border-rose-100">
                      <span className="text-[10px] font-bold text-rose-700 uppercase">Subskala Depresi</span>
                      <div className="text-lg font-black text-rose-900 mt-0.5">
                        {testCompletedResult.subscaleScores?.depression ?? 0}
                      </div>
                    </div>
                    <div className="p-3 bg-amber-50 rounded-xl border border-amber-100">
                      <span className="text-[10px] font-bold text-amber-700 uppercase">Subskala Kecemasan</span>
                      <div className="text-lg font-black text-amber-900 mt-0.5">
                        {testCompletedResult.subscaleScores?.anxiety ?? 0}
                      </div>
                    </div>
                    <div className="p-3 bg-teal-50 rounded-xl border border-teal-100">
                      <span className="text-[10px] font-bold text-teal-700 uppercase">Subskala Stres</span>
                      <div className="text-lg font-black text-teal-900 mt-0.5">
                        {testCompletedResult.subscaleScores?.stress ?? 0}
                      </div>
                    </div>
                  </div>

                  {/* Clinical Interpretations */}
                  <div className="p-4 bg-teal-50/70 border border-teal-200 rounded-2xl space-y-2">
                    <div className="font-bold text-teal-950">Interpretasi Klinis:</div>
                    <p className="text-teal-900 leading-relaxed">{testCompletedResult.interpretation}</p>
                    <div className="font-bold text-teal-950 pt-1">Rekomendasi Psikolog:</div>
                    <p className="text-teal-900 leading-relaxed">{testCompletedResult.clinicalRecommendation}</p>
                  </div>
                </div>

                <div className="pt-2 flex flex-col sm:flex-row items-center gap-2">
                  <button
                    onClick={() => {
                      setTestCompletedResult(null);
                      setActivePatientTab('booking');
                    }}
                    className="w-full sm:flex-1 py-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                  >
                    Konsultasikan Hasil Ini dengan Psikolog
                  </button>
                  <button
                    onClick={() => setTestCompletedResult(null)}
                    className="w-full sm:w-auto px-5 py-3 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition-colors"
                  >
                    Tutup
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 5: REALTIME CHAT ROOM */}
      {activePatientTab === 'chat' && (
        <div className="py-6">
          {activeChatApt ? (
            <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs max-w-4xl mx-auto flex flex-col h-[640px]">
              {/* Chat Top Navigation Bar */}
              <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
                    PSI
                  </div>
                  <div>
                    <div className="text-sm font-bold flex items-center gap-2">
                      {activeChatApt.psychologistName}
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    </div>
                    <div className="text-[11px] text-emerald-300">
                      Sesi: {activeChatApt.packageName} • #{activeChatApt.bookingCode}
                    </div>
                  </div>
                </div>

                {/* Auto Timer Countdown */}
                <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700 text-xs">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-slate-300">Sisa Sesi:</span>
                  <span className="font-mono font-bold text-amber-300">{chatTimerMinutes}:24 Menit</span>
                </div>
              </div>

              {/* Chat Messages Log */}
              <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-50">
                {currentMessages.map(msg => {
                  const isMe = msg.senderRole === 'PATIENT';
                  const isSys = msg.senderRole === 'SYSTEM';

                  if (isSys) {
                    return (
                      <div key={msg.id} className="flex justify-center my-2">
                        <div className="px-4 py-1.5 bg-slate-200/80 rounded-full text-[11px] text-slate-600 font-medium text-center max-w-md">
                          {msg.text}
                        </div>
                      </div>
                    );
                  }

                  return (
                    <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                      <div
                        className={`max-w-md p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                          isMe
                            ? 'bg-emerald-700 text-white rounded-tr-none shadow-xs'
                            : 'bg-white text-slate-800 rounded-tl-none border border-slate-200 shadow-xs'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-4 mb-1">
                          <span className={`text-[10px] font-bold ${isMe ? 'text-emerald-200' : 'text-teal-700'}`}>
                            {msg.senderName}
                          </span>
                          <span className={`text-[10px] ${isMe ? 'text-emerald-300' : 'text-slate-400'}`}>
                            {msg.timestamp}
                          </span>
                        </div>
                        <p>{msg.text}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Quick Therapeutic Prompt Suggestions */}
              <div className="px-4 py-2 bg-white border-t border-slate-100 flex items-center gap-2 overflow-x-auto text-[11px]">
                <span className="text-slate-400 font-bold whitespace-nowrap">Saran Percakapan:</span>
                {[
                  'Dada saya terasa sesak saat bangun pagi',
                  'Bagaimana cara latihan pernapasan 4-7-8?',
                  'Saya cemas berlebih memikirkan presentasi kantor'
                ].map(prompt => (
                  <button
                    key={prompt}
                    type="button"
                    onClick={() => {
                      sendChatMessage(activeChatApt.id, prompt);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 text-slate-700 whitespace-nowrap transition-colors"
                  >
                    "{prompt}"
                  </button>
                ))}
              </div>

              {/* Chat Input Box */}
              <form onSubmit={handleSendMessage} className="p-3 bg-white border-t border-slate-200 flex gap-2">
                <input
                  type="text"
                  value={chatInput}
                  onChange={e => setChatInput(e.target.value)}
                  placeholder="Ketik pesan konsultasi Anda di sini..."
                  className="flex-1 px-4 py-3 bg-slate-100 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
                <button
                  type="submit"
                  className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs"
                >
                  <Send className="w-4 h-4" />
                  <span>Kirim</span>
                </button>
              </form>
            </div>
          ) : (
            <div className="p-10 text-center bg-white rounded-3xl border border-slate-200 max-w-xl mx-auto">
              <MessageSquare className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800">Tidak Ada Sesi Chat yang Sedang Aktif</h3>
              <p className="text-xs text-slate-500 mt-1">
                Ruang chat akan aktif saat jadwal konsultasi tiba atau Anda dapat membuat reservasi sesi baru.
              </p>
              <button
                onClick={() => setActivePatientTab('booking')}
                className="mt-4 px-5 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold"
              >
                Pesan Sesi Baru
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 6: HISTORY & REVIEW */}
      {activePatientTab === 'history' && (
        <div className="py-6 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
              <div>
                <h3 className="text-xl font-extrabold text-slate-900">Riwayat Janji Temu Konsultasi</h3>
                <p className="text-xs text-slate-500 mt-0.5">Daftar seluruh sesi Anda yang telah dipesan, berlangsung, atau selesai.</p>
              </div>
            </div>

            <div className="space-y-4">
              {patientAppointments.map(apt => (
                <div
                  key={apt.id}
                  className="p-5 rounded-2xl border border-slate-200 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono text-xs font-bold text-slate-900">{apt.bookingCode}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          apt.status === 'CONFIRMED'
                            ? 'bg-emerald-100 text-emerald-800'
                            : apt.status === 'COMPLETED'
                            ? 'bg-slate-200 text-slate-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {apt.status}
                      </span>
                    </div>

                    <div className="text-sm font-bold text-slate-900">{apt.packageName}</div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      Psikolog: <strong>{apt.psychologistName}</strong> • {apt.date} ({apt.startTime} - {apt.endTime} WIB)
                    </div>
                    <div className="text-[11px] text-teal-700 font-semibold mt-1">
                      Lokasi: {apt.meetingLocation} • Rp {apt.totalAmount.toLocaleString('id-ID')} ({apt.paymentStatus})
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {apt.status === 'COMPLETED' && !apt.reviewId && (
                      <button
                        onClick={() => setReviewModalAptId(apt.id)}
                        className="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs"
                      >
                        <Star className="w-3.5 h-3.5 fill-white" />
                        Beri Ulasan & Rating
                      </button>
                    )}
                    {apt.status === 'CONFIRMED' && (
                      <button
                        onClick={() => setActivePatientTab('chat')}
                        className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        Masuk Chat
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* MODAL REVIEW POST-SESSION */}
      {reviewModalAptId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100 mb-4">
              <h4 className="text-base font-bold text-slate-900">Ulasan Sesi Konsultasi</h4>
              <button onClick={() => setReviewModalAptId(null)} className="text-slate-400 font-bold">
                ✕
              </button>
            </div>

            <form onSubmit={handleReviewSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Tingkat Kepuasan (Rating Bintang)</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map(star => (
                    <button
                      type="button"
                      key={star}
                      onClick={() => setReviewRating(star)}
                      className="p-1.5 rounded-lg hover:bg-amber-50"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          star <= reviewRating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Ceritakan Pengalaman Konsultasi</label>
                <textarea
                  rows={4}
                  required
                  value={reviewComment}
                  onChange={e => setReviewComment(e.target.value)}
                  placeholder="Bagaimana perasaan Anda setelah sesi? Apakah psikolog membantu memetakan solusi secara profesional?"
                  className="w-full p-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center gap-3">
                <input
                  type="checkbox"
                  id="anonCheckbox"
                  checked={reviewAnonymous}
                  onChange={e => setReviewAnonymous(e.target.checked)}
                  className="w-4 h-4 accent-emerald-600 rounded"
                />
                <label htmlFor="anonCheckbox" className="text-xs text-slate-700 cursor-pointer">
                  <strong>Tampilkan sebagai Anonim</strong> di halaman ulasan publik demi privasi Anda.
                </label>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setReviewModalAptId(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs"
                >
                  Kirim Ulasan ke Admin
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
