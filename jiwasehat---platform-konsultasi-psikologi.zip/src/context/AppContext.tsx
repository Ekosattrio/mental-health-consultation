import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  UserRole,
  PsychologistProfile,
  ConsultationPackage,
  PsychologicalTest,
  ScheduleSlot,
  Appointment,
  TestResult,
  IntakeForm,
  ClinicalNote,
  Review,
  ChatMessage,
  AnalyticsSummary,
  ToastNotification
} from '../types';
import {
  INITIAL_USERS,
  INITIAL_PSYCHOLOGISTS,
  INITIAL_PACKAGES,
  INITIAL_TESTS,
  INITIAL_INTAKE_FORMS,
  INITIAL_TEST_RESULTS,
  INITIAL_SCHEDULES,
  INITIAL_APPOINTMENTS,
  INITIAL_CHAT_MESSAGES,
  INITIAL_CLINICAL_NOTES,
  INITIAL_REVIEWS
} from '../data/mockData';

interface AppContextType {
  currentUser: User | null;
  currentRole: UserRole;
  currentPsychologistProfile: PsychologistProfile | null;
  users: User[];
  psychologists: PsychologistProfile[];
  packages: ConsultationPackage[];
  tests: PsychologicalTest[];
  schedules: ScheduleSlot[];
  appointments: Appointment[];
  testResults: TestResult[];
  intakeForms: Record<string, IntakeForm>;
  clinicalNotes: Record<string, ClinicalNote>;
  reviews: Review[];
  chatMessages: Record<string, ChatMessage[]>;
  analytics: AnalyticsSummary;
  toast: ToastNotification | null;
  
  // Navigation & View
  viewMode: 'PLATFORM' | 'BLUEPRINT';
  setViewMode: (mode: 'PLATFORM' | 'BLUEPRINT') => void;
  activePatientTab: 'overview' | 'booking' | 'tests' | 'intake' | 'chat' | 'history';
  setActivePatientTab: (tab: 'overview' | 'booking' | 'tests' | 'intake' | 'chat' | 'history') => void;
  activePsychologistTab: 'overview' | 'schedule' | 'patients' | 'chat' | 'history' | 'profile';
  setActivePsychologistTab: (tab: 'overview' | 'schedule' | 'patients' | 'chat' | 'history' | 'profile') => void;
  activeAdminTab: 'analytics' | 'users' | 'packages' | 'tests' | 'reservations' | 'reviews';
  setActiveAdminTab: (tab: 'analytics' | 'users' | 'packages' | 'tests' | 'reservations' | 'reviews') => void;

  // Actions
  switchRole: (role: UserRole, specificUserId?: string) => void;
  switchPatientUser: (patientId: string) => void;
  showToast: (title: string, message: string, type?: 'success' | 'info' | 'error' | 'warning') => void;
  dismissToast: () => void;
  bookAppointment: (data: {
    patientId: string;
    patientName: string;
    patientEmail: string;
    psychologistId: string;
    packageId: string;
    date: string;
    slotId: string;
    paymentMethod?: string;
  }) => { success: boolean; message: string; appointment?: Appointment };
  
  submitIntakeForm: (formData: Omit<IntakeForm, 'id' | 'completedAt'>) => void;
  submitTestResult: (resultData: Omit<TestResult, 'id' | 'completedAt'>) => TestResult;
  sendChatMessage: (appointmentId: string, text: string) => void;
  saveClinicalNotes: (appointmentId: string, notes: Omit<ClinicalNote, 'id' | 'createdAt' | 'updatedAt'>) => void;
  submitReview: (reviewData: {
    appointmentId: string;
    psychologistId: string;
    rating: number;
    comment: string;
    isAnonymous: boolean;
  }) => void;
  approveReview: (reviewId: string) => void;
  rejectReview: (reviewId: string) => void;
  toggleUserStatus: (userId: string, status: 'ACTIVE' | 'BLOCKED' | 'PENDING_VERIFICATION') => void;
  updatePsychologistProfile: (profile: Partial<PsychologistProfile>) => void;
  toggleSlotAvailability: (slotId: string) => void;
  addScheduleSlot: (psychologistId: string, date: string, startTime: string, endTime: string) => boolean;
  deleteScheduleSlot: (slotId: string) => void;
  savePackage: (pkg: ConsultationPackage) => void;
  deletePackage: (packageId: string) => void;
  saveTest: (test: PsychologicalTest) => void;
  updateAppointmentStatus: (aptId: string, status: Appointment['status']) => void;
  resetAllToDefault: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_PREFIX = 'jiwasehat_v2_';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Persistence helpers
  const loadState = <T,>(key: string, defaultVal: T): T => {
    try {
      const item = localStorage.getItem(STORAGE_PREFIX + key);
      return item ? JSON.parse(item) : defaultVal;
    } catch {
      return defaultVal;
    }
  };

  const [currentRole, setCurrentRole] = useState<UserRole>('GUEST');
  const [viewMode, setViewMode] = useState<'PLATFORM' | 'BLUEPRINT'>('PLATFORM');
  const [users, setUsers] = useState<User[]>(() => loadState('users', INITIAL_USERS));
  const [psychologists, setPsychologists] = useState<PsychologistProfile[]>(() => loadState('psychologists', INITIAL_PSYCHOLOGISTS));
  const [packages, setPackages] = useState<ConsultationPackage[]>(() => loadState('packages', INITIAL_PACKAGES));
  const [tests, setTests] = useState<PsychologicalTest[]>(() => loadState('tests', INITIAL_TESTS));
  const [schedules, setSchedules] = useState<ScheduleSlot[]>(() => loadState('schedules', INITIAL_SCHEDULES));
  const [appointments, setAppointments] = useState<Appointment[]>(() => loadState('appointments', INITIAL_APPOINTMENTS));
  const [testResults, setTestResults] = useState<TestResult[]>(() => loadState('testResults', INITIAL_TEST_RESULTS));
  const [intakeForms, setIntakeForms] = useState<Record<string, IntakeForm>>(() => loadState('intakeForms', INITIAL_INTAKE_FORMS));
  const [clinicalNotes, setClinicalNotes] = useState<Record<string, ClinicalNote>>(() => loadState('clinicalNotes', INITIAL_CLINICAL_NOTES));
  const [reviews, setReviews] = useState<Review[]>(() => loadState('reviews', INITIAL_REVIEWS));
  const [chatMessages, setChatMessages] = useState<Record<string, ChatMessage[]>>(() => loadState('chatMessages', INITIAL_CHAT_MESSAGES));

  // Global Toast
  const [toast, setToast] = useState<ToastNotification | null>(null);

  // Tab controllers
  const [activePatientTab, setActivePatientTab] = useState<'overview' | 'booking' | 'tests' | 'intake' | 'chat' | 'history'>('overview');
  const [activePsychologistTab, setActivePsychologistTab] = useState<'overview' | 'schedule' | 'patients' | 'chat' | 'history' | 'profile'>('overview');
  const [activeAdminTab, setActiveAdminTab] = useState<'analytics' | 'users' | 'packages' | 'tests' | 'reservations' | 'reviews'>('analytics');

  // Current active user
  const [currentUserId, setCurrentUserId] = useState<string>('user-pat-1');

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_PREFIX + 'users', JSON.stringify(users));
  }, [users]);
  useEffect(() => {
    localStorage.setItem(STORAGE_PREFIX + 'psychologists', JSON.stringify(psychologists));
  }, [psychologists]);
  useEffect(() => {
    localStorage.setItem(STORAGE_PREFIX + 'packages', JSON.stringify(packages));
  }, [packages]);
  useEffect(() => {
    localStorage.setItem(STORAGE_PREFIX + 'tests', JSON.stringify(tests));
  }, [tests]);
  useEffect(() => {
    localStorage.setItem(STORAGE_PREFIX + 'schedules', JSON.stringify(schedules));
  }, [schedules]);
  useEffect(() => {
    localStorage.setItem(STORAGE_PREFIX + 'appointments', JSON.stringify(appointments));
  }, [appointments]);
  useEffect(() => {
    localStorage.setItem(STORAGE_PREFIX + 'testResults', JSON.stringify(testResults));
  }, [testResults]);
  useEffect(() => {
    localStorage.setItem(STORAGE_PREFIX + 'intakeForms', JSON.stringify(intakeForms));
  }, [intakeForms]);
  useEffect(() => {
    localStorage.setItem(STORAGE_PREFIX + 'clinicalNotes', JSON.stringify(clinicalNotes));
  }, [clinicalNotes]);
  useEffect(() => {
    localStorage.setItem(STORAGE_PREFIX + 'reviews', JSON.stringify(reviews));
  }, [reviews]);
  useEffect(() => {
    localStorage.setItem(STORAGE_PREFIX + 'chatMessages', JSON.stringify(chatMessages));
  }, [chatMessages]);

  const showToast = (title: string, message: string, type: 'success' | 'info' | 'error' | 'warning' = 'success') => {
    const id = `toast-${Date.now()}`;
    setToast({ id, title, message, type });
    setTimeout(() => {
      setToast(curr => (curr?.id === id ? null : curr));
    }, 4000);
  };

  const dismissToast = () => {
    setToast(null);
  };

  const currentUser = currentRole === 'GUEST' ? null : users.find(u => u.id === currentUserId) || users[0];

  const currentPsychologistProfile =
    psychologists.find(p => p.userId === (currentUser?.id ?? 'user-psy-1')) || psychologists[0];

  const switchRole = (role: UserRole, specificUserId?: string) => {
    setCurrentRole(role);
    if (role === 'GUEST') {
      showToast('Mode Publik', 'Beralih ke tampilan Landing Page publik & tamu.');
      return;
    }
    if (specificUserId) {
      setCurrentUserId(specificUserId);
      const targetUser = users.find(u => u.id === specificUserId);
      showToast('Peran Berubah', `Sekarang bertindak sebagai ${targetUser?.name || role}.`);
      return;
    }
    // Set appropriate default user
    if (role === 'PATIENT') {
      setCurrentUserId('user-pat-1');
      setActivePatientTab('overview');
      showToast('Peran Pasien', 'Beralih ke akun Pasien: Budi Santoso (Keluhan: Anxiety & Burnout).');
    } else if (role === 'PSYCHOLOGIST') {
      setCurrentUserId('user-psy-1');
      setActivePsychologistTab('overview');
      showToast('Peran Psikolog', 'Beralih ke akun Praktik: dr. Sarah Jenkins, M.Psi., Psikolog.');
    } else if (role === 'ADMIN') {
      setCurrentUserId('user-adm-1');
      setActiveAdminTab('analytics');
      showToast('Peran Administrator', 'Beralih ke Super Admin JiwaSehat (Hak Akses Penuh).');
    }
  };

  const switchPatientUser = (patientId: string) => {
    setCurrentUserId(patientId);
    const targetUser = users.find(u => u.id === patientId);
    showToast('Ganti Pasien', `Aktif sebagai ${targetUser?.name || 'Pasien'}. Data intake dan tes diperbarui.`);
  };

  // 1. Booking System with Conflict Prevention Logic
  const bookAppointment = (data: {
    patientId: string;
    patientName: string;
    patientEmail: string;
    psychologistId: string;
    packageId: string;
    date: string;
    slotId: string;
    paymentMethod?: string;
  }) => {
    // Check if slot exists
    const slotIndex = schedules.findIndex(s => s.id === data.slotId);
    if (slotIndex === -1) {
      const errMsg = 'Slot waktu yang dipilih tidak ditemukan dalam sistem.';
      showToast('Gagal Booking', errMsg, 'error');
      return { success: false, message: errMsg };
    }

    const slot = schedules[slotIndex];

    // CONFLICT DETECTION (Double-Booking Prevention Guard)
    if (!slot.isAvailable || slot.isBooked) {
      const errMsg = 'Bentrok Jadwal Terdeteksi! Slot waktu ini baru saja dipesan oleh pasien lain atau dinonaktifkan oleh psikolog.';
      showToast('Konflik Jadwal', errMsg, 'error');
      return { success: false, message: errMsg };
    }

    // Verify no overlapping confirmed/in_progress appointment for this psychologist
    const overlappingAppointment = appointments.find(
      apt =>
        apt.psychologistId === data.psychologistId &&
        apt.date === slot.date &&
        apt.startTime === slot.startTime &&
        (apt.status === 'CONFIRMED' || apt.status === 'IN_PROGRESS' || apt.status === 'PENDING')
    );

    if (overlappingAppointment) {
      const errMsg = 'Konflik Reservasi: Psikolog telah memiliki janji temu aktif pada jam tersebut.';
      showToast('Konflik Reservasi', errMsg, 'error');
      return { success: false, message: errMsg };
    }

    const selectedPkg = packages.find(p => p.id === data.packageId) || packages[0];
    const targetPsychologist = users.find(u => u.id === data.psychologistId);
    const bookingCode = `JS-${data.date.replace(/-/g, '')}-${Math.floor(1000 + Math.random() * 9000)}`;
    const appointmentId = `apt-${Date.now()}`;

    const newAppointment: Appointment = {
      id: appointmentId,
      bookingCode,
      patientId: data.patientId,
      patientName: data.patientName,
      patientEmail: data.patientEmail,
      psychologistId: data.psychologistId,
      psychologistName: targetPsychologist?.name || 'dr. Sarah Jenkins, M.Psi.',
      packageId: selectedPkg.id,
      packageName: selectedPkg.name,
      packageType: selectedPkg.type,
      date: slot.date,
      startTime: slot.startTime,
      endTime: slot.endTime,
      status: 'CONFIRMED',
      paymentStatus: 'PAID',
      totalAmount: selectedPkg.price,
      meetingLocation:
        selectedPkg.type === 'OFFLINE_CLINIC'
          ? 'Klinik JiwaSehat Ruang Lavender Lt. 3'
          : `Room-Live-${bookingCode.slice(-4)}`,
      hasIntakeForm: !!intakeForms[data.patientId],
      hasTestResult: testResults.some(r => r.patientId === data.patientId),
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 16)
    };

    // Update schedule slot atomically
    const updatedSchedules = [...schedules];
    updatedSchedules[slotIndex] = {
      ...slot,
      isAvailable: false,
      isBooked: true,
      appointmentId
    };

    // Initialize initial greeting chat message if online chat
    if (selectedPkg.type === 'ONLINE_CHAT' || selectedPkg.type === 'BUNDLING_ASSESSMENT') {
      const initialSystemMsg: ChatMessage = {
        id: `msg-${Date.now()}`,
        appointmentId,
        senderId: 'system',
        senderRole: 'SYSTEM',
        senderName: 'Sistem JiwaSehat',
        text: `Ruang konsultasi privat #${bookingCode} siap. Sesi dijadwalkan pada ${slot.date} pukul ${slot.startTime} - ${slot.endTime} WIB. Metode: ${data.paymentMethod || 'QRIS Terverifikasi'}.`,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      };
      setChatMessages(prev => ({
        ...prev,
        [appointmentId]: [initialSystemMsg]
      }));
    }

    setSchedules(updatedSchedules);
    setAppointments(prev => [newAppointment, ...prev]);

    showToast('Reservasi Terkonfirmasi', `Jadwal sesi ${slot.date} jam ${slot.startTime} WIB berhasil dibooking!`, 'success');

    return {
      success: true,
      message: 'Reservasi berhasil dikonfirmasi! Jadwal Anda telah terdaftar dan slot waktu terkunci.',
      appointment: newAppointment
    };
  };

  // 2. Intake Form Submission
  const submitIntakeForm = (formData: Omit<IntakeForm, 'id' | 'completedAt'>) => {
    const newForm: IntakeForm = {
      ...formData,
      id: `intake-${formData.patientId}`,
      completedAt: new Date().toISOString().replace('T', ' ').slice(0, 16)
    };

    setIntakeForms(prev => ({
      ...prev,
      [formData.patientId]: newForm
    }));

    // Update patient status in appointments
    setAppointments(prev =>
      prev.map(apt => (apt.patientId === formData.patientId ? { ...apt, hasIntakeForm: true } : apt))
    );

    showToast('Formulir Intake Tersimpan', 'Data klinis, riwayat medis, dan keluhan berhasil diperbarui di rekam medis.', 'success');
  };

  // 3. Test Result Submission
  const submitTestResult = (resultData: Omit<TestResult, 'id' | 'completedAt'>) => {
    const newResult: TestResult = {
      ...resultData,
      id: `res-${Date.now()}`,
      completedAt: new Date().toISOString().replace('T', ' ').slice(0, 16)
    };

    setTestResults(prev => [newResult, ...prev]);

    // Update appointments
    setAppointments(prev =>
      prev.map(apt => (apt.patientId === resultData.patientId ? { ...apt, hasTestResult: true } : apt))
    );

    showToast(
      'Asesmen DASS-21 Selesai',
      `Skor berhasil dihitung: ${newResult.severityLevel}. Tersimpan di rekam medis Anda.`,
      'success'
    );

    return newResult;
  };

  // 4. Realtime Chat Simulation with Psychologist Auto-Response
  const sendChatMessage = (appointmentId: string, text: string) => {
    if (!text.trim()) return;
    const now = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    const isPatient = currentUser?.role === 'PATIENT';
    const currentApt = appointments.find(a => a.id === appointmentId);

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      appointmentId,
      senderId: currentUser?.id || 'guest',
      senderRole: isPatient ? 'PATIENT' : 'PSYCHOLOGIST',
      senderName: currentUser?.name || (isPatient ? 'Pasien' : 'Psikolog'),
      text: text.trim(),
      timestamp: now
    };

    setChatMessages(prev => ({
      ...prev,
      [appointmentId]: [...(prev[appointmentId] || []), newMsg]
    }));

    // If patient sent message, simulate psychologist listening and replying in 1.4s
    if (isPatient) {
      setTimeout(() => {
        const replies = [
          'Saya sangat memahami apa yang Anda rasakan. Ceritakan lebih lanjut, apa yang biasanya Anda lakukan saat pikiran itu mulai mengganggu?',
          'Terima kasih sudah memvalidasi perasaan tersebut dengan terbuka, Mas Budi. Mari kita identifikasi bersama pemicu utamanya.',
          'Bagus sekali Anda bisa menyadarinya. Apakah sensasi fisik seperti sesak atau detak jantung cepat juga menyertai saat momen itu terjadi?',
          'Mari kita coba latihan teknik relaksasi pernapasan 4-7-8 untuk meredakan ketegangan ini sejenak. Tarik napas 4 detik, tahan 7 detik, lalu hembuskan perlahan 8 detik.'
        ];
        const randomReply = replies[Math.floor(Math.random() * replies.length)];
        const docReply: ChatMessage = {
          id: `msg-doc-${Date.now()}`,
          appointmentId,
          senderId: currentApt?.psychologistId || 'user-psy-1',
          senderRole: 'PSYCHOLOGIST',
          senderName: currentApt?.psychologistName || 'dr. Sarah Jenkins, M.Psi.',
          text: randomReply,
          timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
        };
        setChatMessages(curr => ({
          ...curr,
          [appointmentId]: [...(curr[appointmentId] || []), docReply]
        }));
      }, 1400);
    }
  };

  // 5. Clinical Progress Notes (SOAP)
  const saveClinicalNotes = (
    appointmentId: string,
    notes: Omit<ClinicalNote, 'id' | 'createdAt' | 'updatedAt'>
  ) => {
    const existing = clinicalNotes[appointmentId];
    const timestamp = new Date().toISOString().replace('T', ' ').slice(0, 16);
    const updatedNote: ClinicalNote = {
      ...notes,
      id: existing?.id || `note-${appointmentId}`,
      createdAt: existing?.createdAt || timestamp,
      updatedAt: timestamp
    };

    setClinicalNotes(prev => ({
      ...prev,
      [appointmentId]: updatedNote
    }));

    // Link note to appointment
    setAppointments(prev =>
      prev.map(apt => (apt.id === appointmentId ? { ...apt, clinicalNotesId: updatedNote.id, status: 'COMPLETED' } : apt))
    );

    showToast('Catatan SOAP Tersimpan', 'Catatan perkembangan klinis pasien berhasil diperbarui ke EMR medis.', 'success');
  };

  // 6. Review & Rating
  const submitReview = (data: {
    appointmentId: string;
    psychologistId: string;
    rating: number;
    comment: string;
    isAnonymous: boolean;
  }) => {
    const targetPsychologist = psychologists.find(p => p.userId === data.psychologistId);
    const newRev: Review = {
      id: `rev-${Date.now()}`,
      appointmentId: data.appointmentId,
      patientId: currentUser?.id || 'user-pat-1',
      patientName: currentUser?.name || 'Pasien',
      isAnonymous: data.isAnonymous,
      anonymousAlias: data.isAnonymous ? 'Klien Terverifikasi (Anonim)' : undefined,
      psychologistId: data.psychologistId,
      psychologistName: targetPsychologist?.title
        ? `dr. Sarah Jenkins (${targetPsychologist.title})`
        : 'Psikolog JiwaSehat',
      rating: data.rating,
      comment: data.comment,
      isApproved: false, // Sent to Admin Moderation Queue
      createdAt: new Date().toISOString().slice(0, 10)
    };

    setReviews(prev => [newRev, ...prev]);

    // Update appointment link
    setAppointments(prev =>
      prev.map(apt => (apt.id === data.appointmentId ? { ...apt, reviewId: newRev.id } : apt))
    );

    showToast(
      'Ulasan Terkirim',
      'Terima kasih! Ulasan Anda telah dikirim dan kini berada di antrean moderasi Administrator.',
      'info'
    );
  };

  const approveReview = (reviewId: string) => {
    setReviews(prev =>
      prev.map(r => (r.id === reviewId ? { ...r, isApproved: true } : r))
    );
    showToast('Ulasan Disetujui', 'Ulasan pasien telah dipublikasikan dan kini tayang di Landing Page.', 'success');
  };

  const rejectReview = (reviewId: string) => {
    setReviews(prev => prev.filter(r => r.id !== reviewId));
    showToast('Ulasan Ditolak', 'Ulasan telah dihapus dari sistem.', 'info');
  };

  // 7. Admin: User status toggle
  const toggleUserStatus = (userId: string, status: 'ACTIVE' | 'BLOCKED' | 'PENDING_VERIFICATION') => {
    setUsers(prev =>
      prev.map(u => (u.id === userId ? { ...u, status, isVerified: status === 'ACTIVE' } : u))
    );
    const target = users.find(u => u.id === userId);
    showToast(
      'Status User Diperbarui',
      `Akun ${target?.name} kini berstatus ${status}.`,
      status === 'ACTIVE' ? 'success' : 'warning'
    );
  };

  // 8. Psychologist: Profile management
  const updatePsychologistProfile = (profileUpdate: Partial<PsychologistProfile>) => {
    const targetId = currentUser?.id || 'user-psy-1';
    setPsychologists(prev =>
      prev.map(p => (p.userId === targetId ? { ...p, ...profileUpdate } : p))
    );
    showToast('Profil Diperbarui', 'Tarif konsultasi dan biografi profesional Anda berhasil disimpan.', 'success');
  };

  // 9. Psychologist: Schedule Slot Management
  const toggleSlotAvailability = (slotId: string) => {
    setSchedules(prev =>
      prev.map(s => (s.id === slotId ? { ...s, isAvailable: !s.isAvailable } : s))
    );
    showToast('Slot Diperbarui', 'Ketersediaan slot jadwal berhasil diubah.', 'info');
  };

  const addScheduleSlot = (psychologistId: string, date: string, startTime: string, endTime: string): boolean => {
    // Prevent duplicate slot
    const exists = schedules.some(
      s => s.psychologistId === psychologistId && s.date === date && s.startTime === startTime
    );
    if (exists) {
      showToast('Gagal Tambah Slot', 'Slot dengan tanggal dan jam tersebut sudah terdaftar.', 'error');
      return false;
    }

    const newSlot: ScheduleSlot = {
      id: `slot-${Date.now()}`,
      psychologistId,
      date,
      startTime,
      endTime,
      isAvailable: true,
      isBooked: false
    };

    setSchedules(prev => [...prev, newSlot]);
    showToast('Slot Ditambahkan', `Slot baru ${date} pukul ${startTime} - ${endTime} WIB berhasil dibuka.`, 'success');
    return true;
  };

  const deleteScheduleSlot = (slotId: string) => {
    setSchedules(prev => prev.filter(s => s.id !== slotId));
    showToast('Slot Dihapus', 'Slot jadwal berhasil dihapus dari kalender.', 'info');
  };

  // 10. Admin: Packages & Tests CRUD
  const savePackage = (pkg: ConsultationPackage) => {
    setPackages(prev => {
      const idx = prev.findIndex(p => p.id === pkg.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = pkg;
        return next;
      }
      return [...prev, pkg];
    });
    showToast('Paket Disimpan', `Paket layanan "${pkg.name}" berhasil disimpan.`, 'success');
  };

  const deletePackage = (packageId: string) => {
    setPackages(prev => prev.filter(p => p.id !== packageId));
    showToast('Paket Dihapus', 'Paket layanan telah dihapus dari katalog.', 'info');
  };

  const saveTest = (test: PsychologicalTest) => {
    setTests(prev => {
      const idx = prev.findIndex(t => t.id === test.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = test;
        return next;
      }
      return [...prev, test];
    });
    showToast('Instrumen Tes Disimpan', `Instrumen ${test.title} berhasil diperbarui.`, 'success');
  };

  const updateAppointmentStatus = (aptId: string, status: Appointment['status']) => {
    setAppointments(prev =>
      prev.map(apt => (apt.id === aptId ? { ...apt, status } : apt))
    );
    showToast('Status Reservasi', `Status reservasi #${aptId.slice(-6)} diubah menjadi ${status}.`, 'info');
  };

  const resetAllToDefault = () => {
    localStorage.removeItem(STORAGE_PREFIX + 'users');
    localStorage.removeItem(STORAGE_PREFIX + 'psychologists');
    localStorage.removeItem(STORAGE_PREFIX + 'packages');
    localStorage.removeItem(STORAGE_PREFIX + 'tests');
    localStorage.removeItem(STORAGE_PREFIX + 'schedules');
    localStorage.removeItem(STORAGE_PREFIX + 'appointments');
    localStorage.removeItem(STORAGE_PREFIX + 'testResults');
    localStorage.removeItem(STORAGE_PREFIX + 'intakeForms');
    localStorage.removeItem(STORAGE_PREFIX + 'clinicalNotes');
    localStorage.removeItem(STORAGE_PREFIX + 'reviews');
    localStorage.removeItem(STORAGE_PREFIX + 'chatMessages');

    setUsers(INITIAL_USERS);
    setPsychologists(INITIAL_PSYCHOLOGISTS);
    setPackages(INITIAL_PACKAGES);
    setTests(INITIAL_TESTS);
    setSchedules(INITIAL_SCHEDULES);
    setAppointments(INITIAL_APPOINTMENTS);
    setTestResults(INITIAL_TEST_RESULTS);
    setIntakeForms(INITIAL_INTAKE_FORMS);
    setClinicalNotes(INITIAL_CLINICAL_NOTES);
    setReviews(INITIAL_REVIEWS);
    setChatMessages(INITIAL_CHAT_MESSAGES);
    setCurrentUserId('user-pat-1');
    setCurrentRole('GUEST');

    showToast('Data Direset', 'Seluruh data demo telah dikembalikan ke kondisi awal pabrik.', 'info');
  };

  // Compute live analytics
  const approvedReviews = reviews.filter(r => r.isApproved);
  const avgRating =
    approvedReviews.length > 0
      ? Number((approvedReviews.reduce((acc, r) => acc + r.rating, 0) / approvedReviews.length).toFixed(1))
      : 4.9;

  const totalRev = appointments
    .filter(a => a.paymentStatus === 'PAID')
    .reduce((acc, a) => acc + a.totalAmount, 0);

  const analytics: AnalyticsSummary = {
    totalAppointments: appointments.length,
    completedSessions: appointments.filter(a => a.status === 'COMPLETED').length,
    totalRevenue: totalRev,
    activePatients: new Set(appointments.map(a => a.patientId)).size,
    averageRating: avgRating,
    psychologistCount: psychologists.length,
    pendingReviews: reviews.filter(r => !r.isApproved).length,
    topConcerns: [
      { name: 'Kecemasan (Anxiety) & Panic Attack', count: 28, percentage: 38 },
      { name: 'Burnout & Stres Lingkungan Kerja', count: 22, percentage: 30 },
      { name: 'Insomnia & Overthinking Malam Hari', count: 14, percentage: 19 },
      { name: 'Depresi Ringan & Motivasi Akademik', count: 9, percentage: 13 }
    ]
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        currentRole,
        currentPsychologistProfile,
        users,
        psychologists,
        packages,
        tests,
        schedules,
        appointments,
        testResults,
        intakeForms,
        clinicalNotes,
        reviews,
        chatMessages,
        analytics,
        toast,
        viewMode,
        setViewMode,
        activePatientTab,
        setActivePatientTab,
        activePsychologistTab,
        setActivePsychologistTab,
        activeAdminTab,
        setActiveAdminTab,
        switchRole,
        switchPatientUser,
        showToast,
        dismissToast,
        bookAppointment,
        submitIntakeForm,
        submitTestResult,
        sendChatMessage,
        saveClinicalNotes,
        submitReview,
        approveReview,
        rejectReview,
        toggleUserStatus,
        updatePsychologistProfile,
        toggleSlotAvailability,
        addScheduleSlot,
        deleteScheduleSlot,
        savePackage,
        deletePackage,
        saveTest,
        updateAppointmentStatus,
        resetAllToDefault
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
