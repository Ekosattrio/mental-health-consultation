import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import {
  HeartHandshake,
  Shield,
  UserCheck,
  Stethoscope,
  BookOpen,
  PhoneCall,
  RotateCcw,
  Sparkles,
  ChevronDown
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    currentRole,
    currentUser,
    users,
    switchRole,
    switchPatientUser,
    viewMode,
    setViewMode,
    resetAllToDefault
  } = useApp();

  const [roleMenuOpen, setRoleMenuOpen] = useState(false);
  const [crisisModalOpen, setCrisisModalOpen] = useState(false);

  const roles: { role: UserRole; label: string; desc: string; icon: React.ReactNode; color: string }[] = [
    {
      role: 'GUEST',
      label: 'Publik / Tamu',
      desc: 'Landing page, biografi, katalog paket, lokasi, & review publik',
      icon: <BookOpen className="w-4 h-4" />,
      color: 'text-slate-600 bg-slate-100'
    },
    {
      role: 'PATIENT',
      label: 'Pasien (Budi Santoso)',
      desc: 'Booking, intake form, tes DASS-21, chat sesi, review',
      icon: <UserCheck className="w-4 h-4" />,
      color: 'text-emerald-700 bg-emerald-50'
    },
    {
      role: 'PSYCHOLOGIST',
      label: 'Psikolog (dr. Sarah Jenkins, M.Psi.)',
      desc: 'Jadwal, EMR rekam medis, tes pasien, SOAP notes, chat',
      icon: <Stethoscope className="w-4 h-4" />,
      color: 'text-sky-700 bg-sky-50'
    },
    {
      role: 'ADMIN',
      label: 'Admin (Super Admin)',
      desc: 'User management, verifikasi STR, moderasi review, CRUD',
      icon: <Shield className="w-4 h-4" />,
      color: 'text-purple-700 bg-purple-50'
    }
  ];

  const currentRoleInfo = roles.find(r => r.role === currentRole) || roles[0];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Top Emergency Hotline Notification Bar */}
      <div className="bg-gradient-to-r from-teal-900 to-slate-900 text-teal-100 text-xs px-4 py-1.5 flex items-center justify-between">
        <div className="flex items-center gap-2 max-w-7xl mx-auto w-full justify-between">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-rose-500 text-white animate-pulse">
              HOTLINE KRISIS
            </span>
            <span className="hidden sm:inline text-slate-200">
              Butuh pertolongan darurat mental? Layanan Kemenkes Sejiwa <strong>119 ext 8</strong> (24 Jam Gratis).
            </span>
          </div>
          <button
            onClick={() => setCrisisModalOpen(true)}
            className="flex items-center gap-1 text-teal-300 hover:text-white underline text-[11px] font-medium transition-colors"
          >
            <PhoneCall className="w-3 h-3" />
            Kontak Darurat
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setViewMode('PLATFORM')}>
            <div className="w-10 h-10 rounded-xl bg-teal-600 flex items-center justify-center text-white shadow-sm shadow-teal-500/30">
              <HeartHandshake className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-extrabold text-slate-900 tracking-tight">JiwaSehat</span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 bg-teal-50 text-teal-700 border border-teal-200 rounded">
                  HIMPSI Certified
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">Platform Konsultasi Psikologi Terintegrasi</p>
            </div>
          </div>

          {/* Center Navigation & Blueprint Switcher */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewMode('PLATFORM')}
              className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-all ${
                viewMode === 'PLATFORM'
                  ? 'bg-teal-50 text-teal-800 border border-teal-300 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Aplikasi Interaktif
            </button>
            <button
              onClick={() => setViewMode('BLUEPRINT')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-semibold transition-all ${
                viewMode === 'BLUEPRINT'
                  ? 'bg-indigo-600 text-white shadow-xs shadow-indigo-500/30'
                  : 'text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              Blueprint Arsitektur & RBAC
            </button>
          </div>

          {/* Right Role Switcher */}
          <div className="relative">
            <div className="flex items-center gap-2">
              <div className="relative">
                <button
                  onClick={() => setRoleMenuOpen(!roleMenuOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 shadow-xs transition-all text-left"
                >
                  <div className={`p-1 rounded-lg ${currentRoleInfo.color}`}>
                    {currentRoleInfo.icon}
                  </div>
                  <div className="hidden sm:block">
                    <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Peran Aktif</div>
                    <div className="text-xs font-bold text-slate-800 flex items-center gap-1">
                      {currentRoleInfo.label}
                      <ChevronDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </div>
                </button>

                {roleMenuOpen && (
                  <div className="absolute right-0 mt-2 w-72 rounded-2xl bg-white border border-slate-200 shadow-xl p-2 z-50 animate-in fade-in-50 duration-150">
                    <div className="px-3 py-2 border-b border-slate-100 mb-1">
                      <p className="text-xs font-bold text-slate-900">Pilih Role Pengguna (Demo)</p>
                      <p className="text-[11px] text-slate-500">Beralih perspektif untuk menguji seluruh alur</p>
                    </div>

                    <div className="space-y-1">
                      {roles.map(r => (
                        <button
                          key={r.role}
                          onClick={() => {
                            switchRole(r.role);
                            setRoleMenuOpen(false);
                            setViewMode('PLATFORM');
                          }}
                          className={`w-full flex items-start gap-3 p-2.5 rounded-xl text-left transition-all ${
                            currentRole === r.role
                              ? 'bg-teal-50/80 border border-teal-200'
                              : 'hover:bg-slate-50 border border-transparent'
                          }`}
                        >
                          <div className={`p-2 rounded-lg mt-0.5 ${r.color}`}>
                            {r.icon}
                          </div>
                          <div>
                            <div className="text-xs font-bold text-slate-900 flex items-center justify-between">
                              {r.label}
                              {currentRole === r.role && (
                                <span className="text-[10px] text-teal-700 bg-teal-100 font-bold px-1.5 py-0.5 rounded">
                                  Aktif
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-slate-500 leading-tight mt-0.5">{r.desc}</p>
                          </div>
                        </button>
                      ))}
                    </div>

                    {/* Patient Sub-Selector if in Patient role */}
                    {currentRole === 'PATIENT' && (
                      <div className="mt-2 pt-2 border-t border-slate-100 px-1">
                        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 px-2">
                          Ganti Pasien Simulasi:
                        </p>
                        <div className="grid grid-cols-1 gap-1">
                          {users.filter(u => u.role === 'PATIENT').map(pat => (
                            <button
                              key={pat.id}
                              onClick={() => {
                                switchPatientUser(pat.id);
                                setRoleMenuOpen(false);
                              }}
                              className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs transition-colors ${
                                currentUser?.id === pat.id
                                  ? 'bg-emerald-100 text-emerald-900 font-semibold'
                                  : 'hover:bg-slate-100 text-slate-700'
                              }`}
                            >
                              <span>{pat.name}</span>
                              <span className="text-[10px] text-slate-500">
                                {pat.id === 'user-pat-1' ? 'Anxiety' : pat.id === 'user-pat-2' ? 'Insomnia' : 'Depresi'}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between px-2">
                      <span className="text-[11px] text-slate-400">User: {currentUser?.name || 'Tamu Publik'}</span>
                      <button
                        onClick={() => {
                          resetAllToDefault();
                          setRoleMenuOpen(false);
                        }}
                        className="text-[10px] text-rose-600 hover:text-rose-700 font-medium flex items-center gap-1"
                        title="Kembalikan data simulasi ke awal"
                      >
                        <RotateCcw className="w-2.5 h-2.5" />
                        Reset Data
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Emergency Crisis Contact Modal */}
      {crisisModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 relative">
            <div className="flex items-center gap-3 mb-4 text-rose-600">
              <div className="p-2.5 bg-rose-50 rounded-xl">
                <PhoneCall className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Saluran Bantuan Krisis</h3>
                <p className="text-xs text-slate-500">Tersedia 24 Jam Setiap Hari Bebas Pulsa</p>
              </div>
            </div>

            <p className="text-sm text-slate-600 mb-4 leading-relaxed">
              Jika Anda atau orang terdekat sedang berada dalam bahaya, mengalami krisis emosional hebat, atau memiliki pikiran untuk menyakiti diri sendiri, segera hubungi kontak darurat berikut:
            </p>

            <div className="space-y-3 mb-6">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-800">Layanan SEJIWA Kemenkes RI</div>
                  <div className="text-xs text-slate-500">Kemenkes Republik Indonesia</div>
                </div>
                <a
                  href="tel:119"
                  className="px-3 py-1.5 bg-rose-600 text-white rounded-lg font-bold text-xs hover:bg-rose-700"
                >
                  Call 119 (ext. 8)
                </a>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-800">Hotline JiwaSehat Crisis Care</div>
                  <div className="text-xs text-slate-500">Tim Siaga Klinik JiwaSehat</div>
                </div>
                <a
                  href="tel:0217654321"
                  className="px-3 py-1.5 bg-teal-600 text-white rounded-lg font-bold text-xs hover:bg-teal-700"
                >
                  (021) 765-4321
                </a>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setCrisisModalOpen(false)}
                className="px-4 py-2 bg-slate-200 text-slate-700 rounded-xl text-sm font-semibold hover:bg-slate-300"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
