import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { ClinicalNote, ScheduleSlot } from '../../types';
import {
  Calendar,
  Clock,
  UserCheck,
  FileText,
  MessageSquare,
  History,
  CheckCircle2,
  AlertCircle,
  Plus,
  Trash2,
  Save,
  Send,
  User,
  ShieldCheck,
  Stethoscope,
  Activity,
  Award,
  Edit3
} from 'lucide-react';

export const PsychologistDashboard: React.FC = () => {
  const {
    currentUser,
    currentPsychologistProfile,
    psychologists,
    users,
    schedules,
    appointments,
    testResults,
    intakeForms,
    clinicalNotes,
    chatMessages,
    activePsychologistTab,
    setActivePsychologistTab,
    updatePsychologistProfile,
    toggleSlotAvailability,
    addScheduleSlot,
    deleteScheduleSlot,
    saveClinicalNotes,
    sendChatMessage
  } = useApp();

  const psychologistId = currentUser?.id || 'user-psy-1';
  const profile = currentPsychologistProfile;

  // Filter psychologist appointments & schedules
  const myAppointments = appointments.filter(a => a.psychologistId === psychologistId);
  const mySchedules = schedules.filter(s => s.psychologistId === psychologistId);
  const activeChatApt = myAppointments.find(a => a.status === 'CONFIRMED' || a.status === 'IN_PROGRESS') || myAppointments[0];

  // Schedule slot form state
  const [slotDate, setSlotDate] = useState('2026-09-17');
  const [slotStartTime, setSlotStartTime] = useState('16:00');
  const [slotEndTime, setSlotEndTime] = useState('17:00');
  const [slotSuccessMsg, setSlotSuccessMsg] = useState<string | null>(null);

  // Profile Editor state
  const [profileBio, setProfileBio] = useState(profile?.bio || '');
  const [profileSpecialties, setProfileSpecialties] = useState(profile?.specialties.join(', ') || '');
  const [profileFeeOnline, setProfileFeeOnline] = useState(profile?.consultationFeeOnline || 250000);
  const [profileFeeOffline, setProfileFeeOffline] = useState(profile?.consultationFeeOffline || 350000);
  const [profileSavedMsg, setProfileSavedMsg] = useState(false);

  // Selected Patient for Medical Record inspection
  const [selectedPatientId, setSelectedPatientId] = useState<string>('user-pat-1');
  const [soapAptId, setSoapAptId] = useState<string>(activeChatApt?.id || 'apt-active-1');
  
  // SOAP Notes state
  const existingSoap = clinicalNotes[soapAptId];
  const [soapSubjective, setSoapSubjective] = useState(existingSoap?.subjective || '');
  const [soapObjective, setSoapObjective] = useState(existingSoap?.objective || '');
  const [soapAssessment, setSoapAssessment] = useState(existingSoap?.assessment || '');
  const [soapPlan, setSoapPlan] = useState(existingSoap?.plan || '');
  const [soapPrognosis, setSoapPrognosis] = useState(existingSoap?.prognosis || 'Baik');
  const [soapSuccessMsg, setSoapSuccessMsg] = useState(false);

  // Sync SOAP notes whenever selected patient or appointment changes
  useEffect(() => {
    // Find appointment for this patient
    const patientApt = appointments.find(a => a.patientId === selectedPatientId && a.psychologistId === psychologistId) ||
      appointments.find(a => a.patientId === selectedPatientId);
    
    const targetAptId = patientApt ? patientApt.id : `apt-${selectedPatientId}-current`;
    setSoapAptId(targetAptId);

    const note = clinicalNotes[targetAptId] || (Object.values(clinicalNotes) as ClinicalNote[]).find(n => n.patientId === selectedPatientId);
    if (note) {
      setSoapSubjective(note.subjective);
      setSoapObjective(note.objective);
      setSoapAssessment(note.assessment);
      setSoapPlan(note.plan);
      setSoapPrognosis(note.prognosis || 'Baik');
    } else {
      // Default draft for new patient observation
      if (selectedPatientId === 'user-pat-2') {
        setSoapSubjective('Pasien mengeluhkan kesulitan memulai tidur (sleep-onset latency > 90 menit) dan pikiran terus berputar (racing thoughts).');
        setSoapObjective('Ekspresi lelah, respon verbal koheren namun lambat. Skor kecemasan subskala DASS-21 berada di tingkat sedang.');
        setSoapAssessment('F51.0 Insomnia Non-organik dengan kecemasan antisipatoris terkait performa kerja.');
        setSoapPlan('Psikoedukasi Sleep Hygiene terstruktur, pembatasan screen-time 1 jam sebelum tidur, teknik progressive muscle relaxation.');
        setSoapPrognosis('Baik');
      } else if (selectedPatientId === 'user-pat-3') {
        setSoapSubjective('Pasien melaporkan anhedonia ringan, penurunan energi dalam 2 pekan terakhir setelah kegagalan proyek studi.');
        setSoapObjective('Kontak mata intermiten, afek datar, tidak ada tanda-tanda ide bunuh diri atau agitasi.');
        setSoapAssessment('F32.0 Episode Depresif Ringan berkaitan dengan stresor akademik/pekerjaan.');
        setSoapPlan('Behavioral Activation: jadwal aktivitas menyenangkan harian bertahap, restrukturisasi kognitif pikiran over-generalisasi.');
        setSoapPrognosis('Baik');
      } else {
        setSoapSubjective('');
        setSoapObjective('');
        setSoapAssessment('');
        setSoapPlan('');
        setSoapPrognosis('Baik');
      }
    }
  }, [selectedPatientId, psychologistId, appointments, clinicalNotes]);

  // Chat message input
  const [chatInput, setChatInput] = useState('');

  const handleAddSlot = (e: React.FormEvent) => {
    e.preventDefault();
    const success = addScheduleSlot(psychologistId, slotDate, slotStartTime, slotEndTime);
    if (success) {
      setSlotSuccessMsg('Slot jadwal baru berhasil ditambahkan!');
      setTimeout(() => setSlotSuccessMsg(null), 3000);
    } else {
      setSlotSuccessMsg('Gagal: Slot dengan jam tersebut sudah ada di tanggal ini.');
      setTimeout(() => setSlotSuccessMsg(null), 3000);
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updatePsychologistProfile({
      bio: profileBio,
      specialties: profileSpecialties.split(',').map(s => s.trim()).filter(Boolean),
      consultationFeeOnline: Number(profileFeeOnline),
      consultationFeeOffline: Number(profileFeeOffline)
    });
    setProfileSavedMsg(true);
    setTimeout(() => setProfileSavedMsg(false), 2500);
  };

  const handleSaveSoap = (e: React.FormEvent) => {
    e.preventDefault();
    saveClinicalNotes(soapAptId, {
      appointmentId: soapAptId,
      patientId: selectedPatientId,
      psychologistId,
      sessionDate: '2026-09-16',
      subjective: soapSubjective,
      objective: soapObjective,
      assessment: soapAssessment,
      plan: soapPlan,
      prognosis: soapPrognosis as any,
      requiresPsychiatristReferral: false
    });
    setSoapSuccessMsg(true);
    setTimeout(() => setSoapSuccessMsg(false), 2500);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !activeChatApt) return;
    sendChatMessage(activeChatApt.id, chatInput);
    setChatInput('');
  };

  const selectedPatientUser = users.find(u => u.id === selectedPatientId);
  const selectedPatientIntake = intakeForms[selectedPatientId];
  const selectedPatientTests = testResults.filter(t => t.patientId === selectedPatientId);
  const currentMessages = activeChatApt ? chatMessages[activeChatApt.id] || [] : [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Psychologist Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-200 gap-4">
        <div className="flex items-center gap-4">
          <img
            src={currentUser?.avatar}
            alt={currentUser?.name}
            className="w-14 h-14 rounded-2xl object-cover border-2 border-sky-500 shadow-sm"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-extrabold text-slate-900">{currentUser?.name}</h1>
              <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-sky-100 text-sky-800 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> Psikolog Berlisensi
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {profile?.title} • SIP: {profile?.sipNumber} • STR: {profile?.strNumber}
            </p>
          </div>
        </div>

        {/* Quick buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActivePsychologistTab('schedule')}
            className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
          >
            <Calendar className="w-4 h-4" />
            Atur Slot Jadwal
          </button>
          <button
            onClick={() => setActivePsychologistTab('chat')}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
          >
            <MessageSquare className="w-4 h-4 text-sky-400" />
            Live Chat Sesi
          </button>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex overflow-x-auto gap-2 py-4 border-b border-slate-200 no-scrollbar">
        {[
          { id: 'overview', label: 'Ringkasan Praktik', icon: <Activity className="w-4 h-4" /> },
          { id: 'schedule', label: 'Manajemen Jadwal (Slots)', icon: <Calendar className="w-4 h-4" /> },
          { id: 'patients', label: 'Rekam Medis & EMR Pasien', icon: <FileText className="w-4 h-4" /> },
          { id: 'chat', label: 'Ruang Chat Realtime', icon: <MessageSquare className="w-4 h-4" /> },
          { id: 'history', label: 'Log Riwayat Konsultasi', icon: <History className="w-4 h-4" /> },
          { id: 'profile', label: 'Profil Profesional', icon: <Edit3 className="w-4 h-4" /> }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActivePsychologistTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              activePsychologistTab === tab.id
                ? 'bg-sky-700 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 bg-white border border-slate-200'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* TAB 1: OVERVIEW */}
      {activePsychologistTab === 'overview' && (
        <div className="py-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-5 bg-white rounded-2xl border border-slate-200">
              <span className="text-xs font-bold text-slate-400 uppercase">Total Sesi Ditangani</span>
              <div className="text-2xl font-extrabold text-slate-900 mt-1">{myAppointments.length} Sesi</div>
              <p className="text-[11px] text-slate-500 mt-0.5">Online & Tatap Muka</p>
            </div>
            <div className="p-5 bg-white rounded-2xl border border-slate-200">
              <span className="text-xs font-bold text-slate-400 uppercase">Slot Waktu Aktif</span>
              <div className="text-2xl font-extrabold text-sky-700 mt-1">
                {mySchedules.filter(s => s.isAvailable).length} Slot
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">Tersedia untuk dibooking</p>
            </div>
            <div className="p-5 bg-white rounded-2xl border border-slate-200">
              <span className="text-xs font-bold text-slate-400 uppercase">Pasien Aktif</span>
              <div className="text-2xl font-extrabold text-slate-900 mt-1">
                {new Set(myAppointments.map(a => a.patientId)).size} Orang
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">Memiliki riwayat terapi</p>
            </div>
            <div className="p-5 bg-white rounded-2xl border border-slate-200">
              <span className="text-xs font-bold text-slate-400 uppercase">Rating Praktik</span>
              <div className="text-2xl font-extrabold text-amber-600 mt-1">{profile?.rating || 4.9} ★</div>
              <p className="text-[11px] text-slate-500 mt-0.5">{profile?.reviewCount || 140} ulasan pasien</p>
            </div>
          </div>

          {/* Active Consultation Banner */}
          {activeChatApt && (
            <div className="p-6 bg-gradient-to-r from-sky-900 to-slate-900 rounded-3xl text-white shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-sky-500/20 text-sky-300 border border-sky-400/30">
                  <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
                  Sesi Konsultasi Terjadwal
                </span>
                <h3 className="text-xl font-bold mt-2">
                  Pasien: {activeChatApt.patientName} ({activeChatApt.packageName})
                </h3>
                <p className="text-xs text-sky-200 mt-1">
                  Jadwal: {activeChatApt.date} • {activeChatApt.startTime} - {activeChatApt.endTime} WIB • Lokasi: {activeChatApt.meetingLocation}
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setSelectedPatientId(activeChatApt.patientId);
                    setSoapAptId(activeChatApt.id);
                    setActivePsychologistTab('patients');
                  }}
                  className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/20"
                >
                  Buka Rekam Medis EMR
                </button>
                <button
                  onClick={() => setActivePsychologistTab('chat')}
                  className="px-5 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-bold flex items-center gap-1.5"
                >
                  <MessageSquare className="w-4 h-4" />
                  Buka Live Chat
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: MANAJEMEN JADWAL (AVAILABILITY & DOUBLE-BOOKING PREVENTION) */}
      {activePsychologistTab === 'schedule' && (
        <div className="py-6 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Form Tambah Slot Baru */}
            <div className="lg:col-span-5 bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
              <h3 className="text-base font-bold text-slate-900 mb-1">Tambah Slot Jadwal Baru</h3>
              <p className="text-xs text-slate-500 mb-4">
                Tentukan jam aktif praktik Anda. Sistem akan memblokir bentrok jam jika waktu tersebut sudah terdaftar.
              </p>

              {slotSuccessMsg && (
                <div className="p-3 bg-sky-50 text-sky-800 rounded-xl text-xs font-semibold mb-4 border border-sky-200">
                  {slotSuccessMsg}
                </div>
              )}

              <form onSubmit={handleAddSlot} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Tanggal Praktik</label>
                  <input
                    type="date"
                    required
                    value={slotDate}
                    onChange={e => setSlotDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Jam Mulai</label>
                    <input
                      type="time"
                      required
                      value={slotStartTime}
                      onChange={e => setSlotStartTime(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Jam Selesai</label>
                    <input
                      type="time"
                      required
                      value={slotEndTime}
                      onChange={e => setSlotEndTime(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  Tambahkan Slot ke Kalender
                </button>
              </form>
            </div>

            {/* List Slot Aktif & Status */}
            <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900">Slot Jadwal & Ketersediaan Anda</h3>
                  <p className="text-xs text-slate-500">Klik tombol status untuk mengaktifkan / menonaktifkan slot libur</p>
                </div>
                <span className="text-xs font-bold text-sky-700">{mySchedules.length} Total Slot</span>
              </div>

              <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1">
                {mySchedules.map(slot => (
                  <div
                    key={slot.id}
                    className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/70 flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="text-xs font-bold text-slate-900">
                        {slot.date} • {slot.startTime} - {slot.endTime} WIB
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        {slot.isBooked ? (
                          <span className="text-rose-600 font-bold">● Terpesan Pasien (Terkunci)</span>
                        ) : slot.isAvailable ? (
                          <span className="text-emerald-700 font-semibold">● Terbuka untuk Booking</span>
                        ) : (
                          <span className="text-slate-400">● Nonaktif / Libur</span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {!slot.isBooked && (
                        <button
                          onClick={() => toggleSlotAvailability(slot.id)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                            slot.isAvailable
                              ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                              : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                          }`}
                        >
                          {slot.isAvailable ? 'Tersedia' : 'Nonaktif'}
                        </button>
                      )}
                      {!slot.isBooked && (
                        <button
                          onClick={() => deleteScheduleSlot(slot.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: DASHBOARD REKAM MEDIS & PASIEN (EMR + SOAP NOTES) */}
      {activePsychologistTab === 'patients' && (
        <div className="py-6 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left: Patient Selector & Intake/Test details */}
            <div className="lg:col-span-5 space-y-6">
              {/* Patient List */}
              <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
                <h3 className="text-base font-bold text-slate-900 mb-3">Daftar Pasien Bimbingan</h3>
                <div className="space-y-2">
                  {users
                    .filter(u => u.role === 'PATIENT')
                    .map(pat => (
                      <div
                        key={pat.id}
                        onClick={() => setSelectedPatientId(pat.id)}
                        className={`p-3 rounded-2xl border cursor-pointer flex items-center gap-3 transition-all ${
                          selectedPatientId === pat.id
                            ? 'bg-sky-50 border-sky-600 ring-1 ring-sky-600'
                            : 'bg-white border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <img src={pat.avatar} alt={pat.name} className="w-10 h-10 rounded-xl object-cover" />
                        <div className="flex-1">
                          <div className="text-xs font-bold text-slate-900">{pat.name}</div>
                          <div className="text-[11px] text-slate-500">{pat.phone}</div>
                        </div>
                        {intakeForms[pat.id] && (
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">
                            Intake Ada
                          </span>
                        )}
                      </div>
                    ))}
                </div>
              </div>

              {/* Patient Intake Form Viewer */}
              <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                  <h4 className="text-sm font-bold text-slate-900">Formulir Intake Pasien</h4>
                  <span className="text-[11px] text-slate-400">ID: {selectedPatientId}</span>
                </div>

                {selectedPatientIntake ? (
                  <div className="space-y-3 text-xs">
                    <div>
                      <span className="font-bold text-slate-700 block">Keluhan Utama:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedPatientIntake.primaryConcerns.map(c => (
                          <span key={c} className="px-2 py-0.5 bg-rose-50 text-rose-700 rounded text-[11px] font-medium">
                            {c}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <span className="font-bold text-slate-700 block">Deskripsi Keluhan:</span>
                      <p className="text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100 italic leading-relaxed mt-1">
                        "{selectedPatientIntake.concernDescription}"
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <div className="p-2 bg-slate-50 rounded-xl">
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Skala Stres</span>
                        <span className="text-sm font-bold text-rose-600">
                          {selectedPatientIntake.currentStressLevel} / 10
                        </span>
                      </div>
                      <div className="p-2 bg-slate-50 rounded-xl">
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Kualitas Tidur</span>
                        <span className="text-xs font-semibold text-slate-800">
                          {selectedPatientIntake.sleepQuality}
                        </span>
                      </div>
                    </div>

                    <div>
                      <span className="font-bold text-slate-700 block">Tujuan Konsultasi:</span>
                      <p className="text-slate-600 mt-0.5">{selectedPatientIntake.goals}</p>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">Pasien belum mengisi formulir intake klinis.</p>
                )}
              </div>

              {/* Psychological Test Results Viewer */}
              <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
                <h4 className="text-sm font-bold text-slate-900 mb-3">Hasil Tes Psikologi (DASS-21)</h4>
                {selectedPatientTests.length > 0 ? (
                  <div className="space-y-3">
                    {selectedPatientTests.map(res => (
                      <div key={res.id} className="p-3 bg-teal-50/50 rounded-2xl border border-teal-100 text-xs">
                        <div className="flex justify-between font-bold text-teal-900 mb-1">
                          <span>{res.testTitle}</span>
                          <span className="px-2 py-0.5 bg-teal-200 rounded text-[10px]">
                            {res.severityLevel}
                          </span>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-center my-2 text-[11px]">
                          <div className="p-1 bg-white rounded">Depresi: {res.subscaleScores.depression || 0}</div>
                          <div className="p-1 bg-white rounded">Kecemasan: {res.subscaleScores.anxiety || 0}</div>
                          <div className="p-1 bg-white rounded">Stres: {res.subscaleScores.stress || 0}</div>
                        </div>
                        <p className="text-[11px] text-teal-800 leading-relaxed">{res.interpretation}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">Belum ada catatan tes psikologi untuk pasien ini.</p>
                )}
              </div>
            </div>

            {/* Right: Clinical Progress Notes (SOAP Format) */}
            <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
                <div>
                  <span className="text-xs font-bold text-sky-600 uppercase tracking-wider">Rekam Medis Elektronik</span>
                  <h3 className="text-xl font-extrabold text-slate-900 mt-0.5">Catatan Klinis Perkembangan (SOAP)</h3>
                  <p className="text-xs text-slate-500">
                    Format baku medis: Subjective, Objective, Assessment, Plan.
                  </p>
                </div>
              </div>

              {soapSuccessMsg && (
                <div className="p-3.5 bg-emerald-50 text-emerald-800 rounded-2xl text-xs font-semibold mb-6 border border-emerald-200 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Catatan perkembangan klinis SOAP berhasil disimpan ke rekam medis pasien!
                </div>
              )}

              <form onSubmit={handleSaveSoap} className="space-y-5">
                {/* S - Subjective */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                    S - Subjective (Keluhan Subyektif & Ungkapan Pasien)
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={soapSubjective}
                    onChange={e => setSoapSubjective(e.target.value)}
                    placeholder="Contoh: Klien menyatakan dada terasa terhimpit saat rapat mingguan dan khawatir dievaluasi negatif oleh rekan..."
                    className="w-full p-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                  />
                </div>

                {/* O - Objective */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                    O - Objective (Observasi Afek, Perilaku Klinis & Skor Tes)
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={soapObjective}
                    onChange={e => setSoapObjective(e.target.value)}
                    placeholder="Contoh: Respons chat terstruktur, afek cemas, skor DASS-21 kecemasan skala sedang (skor 5). Tidak ada tanda agitasi psikomotor..."
                    className="w-full p-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                  />
                </div>

                {/* A - Assessment */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                    A - Assessment (Diagnosis Kerja & Dinamika Psikologis)
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={soapAssessment}
                    onChange={e => setSoapAssessment(e.target.value)}
                    placeholder="Contoh: F41.1 Gangguan Kecemasan Tergeneralisasi (GAD ringan-sedang) dipicu beban kerja berlebih (burnout)..."
                    className="w-full p-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                  />
                </div>

                {/* P - Plan */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                    P - Plan (Rencana Intervensi, PR Klien & Jadwal Lanjutan)
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={soapPlan}
                    onChange={e => setSoapPlan(e.target.value)}
                    placeholder="Contoh: 1. Restrukturisasi kognitif (CBT). 2. PR latihan relaksasi diafragma sebelum tidur. 3. Sesi lanjutan 1 minggu mendatang..."
                    className="w-full p-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Prognosis Klinis</label>
                    <select
                      value={soapPrognosis}
                      onChange={e => setSoapPrognosis(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-white"
                    >
                      <option value="Baik">Baik (Dapat pulih dengan sesi reguler)</option>
                      <option value="Perlu Pemantauan">Perlu Pemantauan Intensif</option>
                      <option value="Butuh Rujukan Psikiater">Butuh Rujukan Medis Psikiater (Farmakoterapi)</option>
                    </select>
                  </div>

                  <div className="flex items-end">
                    <button
                      type="submit"
                      className="w-full py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2"
                    >
                      <Save className="w-4 h-4" />
                      Simpan Catatan Medis SOAP
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: REALTIME CHAT (PSYCHOLOGIST PERSPECTIVE) */}
      {activePsychologistTab === 'chat' && (
        <div className="py-6">
          {activeChatApt ? (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 max-w-6xl mx-auto">
              {/* Chat View */}
              <div className="lg:col-span-8 bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs flex flex-col h-[620px]">
                <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
                  <div>
                    <div className="text-sm font-bold flex items-center gap-2">
                      Pasien: {activeChatApt.patientName}
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    </div>
                    <div className="text-[11px] text-sky-300">
                      Kode: {activeChatApt.bookingCode} • {activeChatApt.packageName}
                    </div>
                  </div>
                  <div className="text-xs bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700 text-slate-300 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    <span>Sesi Terjadwal: {activeChatApt.startTime} - {activeChatApt.endTime}</span>
                  </div>
                </div>

                <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-50">
                  {currentMessages.map(msg => {
                    const isMe = msg.senderRole === 'PSYCHOLOGIST';
                    const isSys = msg.senderRole === 'SYSTEM';

                    if (isSys) {
                      return (
                        <div key={msg.id} className="flex justify-center my-2">
                          <div className="px-4 py-1.5 bg-slate-200/80 rounded-full text-[11px] text-slate-600 font-medium text-center">
                            {msg.text}
                          </div>
                        </div>
                      );
                    }

                    return (
                      <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                        <div
                          className={`max-w-md p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                            isMe
                              ? 'bg-sky-700 text-white rounded-tr-none shadow-xs'
                              : 'bg-white text-slate-800 rounded-tl-none border border-slate-200 shadow-xs'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-4 mb-1">
                            <span className={`text-[10px] font-bold ${isMe ? 'text-sky-200' : 'text-emerald-700'}`}>
                              {msg.senderName}
                            </span>
                            <span className={`text-[10px] ${isMe ? 'text-sky-300' : 'text-slate-400'}`}>
                              {msg.timestamp}
                            </span>
                          </div>
                          <p>{msg.text}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <form onSubmit={handleSendMessage} className="p-3 bg-white border-t border-slate-200 flex gap-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={e => setChatInput(e.target.value)}
                    placeholder="Tulis respons terapeutik psikolog..."
                    className="flex-1 px-4 py-3 bg-slate-100 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                  />
                  <button
                    type="submit"
                    className="px-5 py-3 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs"
                  >
                    <Send className="w-4 h-4" />
                    <span>Kirim</span>
                  </button>
                </form>
              </div>

              {/* Patient Quick Glance Drawer beside Chat */}
              <div className="lg:col-span-4 bg-white rounded-3xl border border-slate-200 p-6 shadow-xs h-[620px] overflow-y-auto space-y-4">
                <h4 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
                  Ringkasan Klien Saat Sesi
                </h4>

                <div className="text-xs space-y-3">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Pasien</span>
                    <span className="font-bold text-slate-800">{activeChatApt.patientName}</span>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Hasil Tes DASS-21</span>
                    <span className="font-bold text-rose-600">Kategori Sedang (Skor 14)</span>
                    <p className="text-[11px] text-slate-500 mt-0.5">Kecemasan: 5/7 • Stres: 5/7</p>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Keluhan Utama Intake</span>
                    <p className="text-[11px] text-slate-700 mt-0.5">
                      Burnout Pekerjaan, Kecemasan Berlebih (Anxiety), Sesak dada pagi hari.
                    </p>
                  </div>

                  <div className="pt-2">
                    <button
                      onClick={() => {
                        setSelectedPatientId(activeChatApt.patientId);
                        setSoapAptId(activeChatApt.id);
                        setActivePsychologistTab('patients');
                      }}
                      className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-bold text-xs"
                    >
                      Buka Form Catatan SOAP
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center bg-white rounded-3xl border border-slate-200 max-w-lg mx-auto">
              <MessageSquare className="w-12 h-12 text-slate-300 mx-auto mb-2" />
              <p className="text-xs text-slate-500">Belum ada sesi janji temu yang aktif saat ini.</p>
            </div>
          )}
        </div>
      )}

      {/* TAB 5: RIWAYAT KONSULTASI LOG */}
      {activePsychologistTab === 'history' && (
        <div className="py-6 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
            <h3 className="text-base font-bold text-slate-900 mb-4">Rekap Histori Seluruh Sesi Konseling</h3>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-500 uppercase font-bold text-[10px] border-y border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Kode Booking</th>
                    <th className="py-3 px-4">Pasien</th>
                    <th className="py-3 px-4">Paket Layanan</th>
                    <th className="py-3 px-4">Tanggal & Jam</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Catatan Medis</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {myAppointments.map(apt => (
                    <tr key={apt.id} className="hover:bg-slate-50/80">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">{apt.bookingCode}</td>
                      <td className="py-3 px-4 font-semibold text-slate-800">{apt.patientName}</td>
                      <td className="py-3 px-4">{apt.packageName}</td>
                      <td className="py-3 px-4">
                        {apt.date} ({apt.startTime} - {apt.endTime})
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            apt.status === 'COMPLETED'
                              ? 'bg-slate-200 text-slate-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {apt.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        {apt.clinicalNotesId ? (
                          <span className="text-emerald-700 font-bold">Tersimpan (SOAP)</span>
                        ) : (
                          <span className="text-amber-600">Belum Ditulis</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: KELOLA PROFIL PROFESIONAL */}
      {activePsychologistTab === 'profile' && (
        <div className="py-6 max-w-3xl mx-auto">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
            <h3 className="text-xl font-extrabold text-slate-900 mb-1">Kelola Profil & Kredensial Praktik</h3>
            <p className="text-xs text-slate-500 mb-6">
              Informasi ini akan ditampilkan pada landing page publik setelah diverifikasi oleh administrator.
            </p>

            {profileSavedMsg && (
              <div className="p-3.5 bg-emerald-50 text-emerald-800 rounded-2xl text-xs font-semibold mb-6 border border-emerald-200 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Profil profesional dan tarif konsultasi Anda berhasil diperbarui!
              </div>
            )}

            <form onSubmit={handleSaveProfile} className="space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Biografi Ringkas & Pengantar</label>
                <textarea
                  rows={4}
                  required
                  value={profileBio}
                  onChange={e => setProfileBio(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Spesialisasi Klinis (Pisahkan dengan koma)
                </label>
                <input
                  type="text"
                  required
                  value={profileSpecialties}
                  onChange={e => setProfileSpecialties(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Tarif Sesi Online (Rp)</label>
                  <input
                    type="number"
                    required
                    value={profileFeeOnline}
                    onChange={e => setProfileFeeOnline(Number(e.target.value))}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Tarif Sesi Tatap Muka (Rp)</label>
                  <input
                    type="number"
                    required
                    value={profileFeeOffline}
                    onChange={e => setProfileFeeOffline(Number(e.target.value))}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  Simpan Perubahan Profil
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
