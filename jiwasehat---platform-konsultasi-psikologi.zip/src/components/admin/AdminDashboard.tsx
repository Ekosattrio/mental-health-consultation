import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ConsultationPackage, PsychologicalTest } from '../../types';
import {
  Users,
  Shield,
  Layers,
  FileCheck,
  CreditCard,
  MessageSquare,
  BarChart3,
  CheckCircle2,
  XCircle,
  Clock,
  Plus,
  Trash2,
  Edit2,
  Star,
  Check,
  Lock,
  Unlock,
  AlertTriangle
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    users,
    psychologists,
    packages,
    tests,
    appointments,
    reviews,
    analytics,
    activeAdminTab,
    setActiveAdminTab,
    toggleUserStatus,
    approveReview,
    rejectReview,
    savePackage,
    deletePackage,
    saveTest,
    updateAppointmentStatus
  } = useApp();

  // Package modal state
  const [editingPackage, setEditingPackage] = useState<ConsultationPackage | null>(null);
  const [isPackageModalOpen, setIsPackageModalOpen] = useState(false);

  // Reservation filter
  const [resStatusFilter, setResStatusFilter] = useState<string>('ALL');

  const filteredAppointments = appointments.filter(apt => {
    if (resStatusFilter === 'ALL') return true;
    return apt.status === resStatusFilter;
  });

  const handleOpenNewPackage = () => {
    setEditingPackage({
      id: `pkg-${Date.now()}`,
      name: '',
      type: 'ONLINE_CHAT',
      durationMinutes: 60,
      price: 200000,
      description: '',
      benefits: ['Sesi privat terenkripsi', 'Rangkuman catatan klinis'],
      isActive: true,
      iconName: 'MessageSquare'
    });
    setIsPackageModalOpen(true);
  };

  const handleSavePackageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPackage || !editingPackage.name) return;
    savePackage(editingPackage);
    setIsPackageModalOpen(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Admin Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-200 gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-purple-600 text-white flex items-center justify-center shadow-sm shadow-purple-500/30">
            <Shield className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-extrabold text-slate-900">Panel Administrator JiwaSehat</h1>
              <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-purple-100 text-purple-800">
                Super Admin Access
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Kelola verifikasi psikolog, moderasi review pasien, monitoring reservasi, dan instrumen asesmen.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500">
            Review Menunggu Moderasi: <strong className="text-amber-600 font-bold">{analytics.pendingReviews}</strong>
          </span>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex overflow-x-auto gap-2 py-4 border-b border-slate-200 no-scrollbar">
        {[
          { id: 'analytics', label: 'Laporan & Analitik', icon: <BarChart3 className="w-4 h-4" /> },
          { id: 'users', label: 'User & Verifikasi Psikolog', icon: <Users className="w-4 h-4" /> },
          { id: 'reservations', label: 'Monitoring Reservasi', icon: <CreditCard className="w-4 h-4" /> },
          { id: 'reviews', label: 'Moderasi Review Pasien', icon: <Star className="w-4 h-4" /> },
          { id: 'packages', label: 'Manajemen Paket', icon: <Layers className="w-4 h-4" /> },
          { id: 'tests', label: 'Instrumen Tes Psikologi', icon: <FileCheck className="w-4 h-4" /> }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveAdminTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              activeAdminTab === tab.id
                ? 'bg-purple-700 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 bg-white border border-slate-200'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* TAB 1: LAPORAN & ANALITIK */}
      {activeAdminTab === 'analytics' && (
        <div className="py-6 space-y-6">
          {/* Top Key Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs">
              <span className="text-xs font-bold text-slate-400 uppercase">Total Estimasi Revenue</span>
              <div className="text-2xl font-black text-slate-900 mt-1">
                Rp {analytics.totalRevenue.toLocaleString('id-ID')}
              </div>
              <p className="text-[11px] text-emerald-700 font-semibold mt-1">
                {analytics.completedSessions} Sesi Selesai Berbayar
              </p>
            </div>

            <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs">
              <span className="text-xs font-bold text-slate-400 uppercase">Total Janji Temu</span>
              <div className="text-2xl font-black text-purple-700 mt-1">{analytics.totalAppointments} Reservasi</div>
              <p className="text-[11px] text-slate-500 mt-1">Online Chat & Tatap Muka Klinik</p>
            </div>

            <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs">
              <span className="text-xs font-bold text-slate-400 uppercase">Pasien Unik Terlayani</span>
              <div className="text-2xl font-black text-slate-900 mt-1">{analytics.activePatients} Orang</div>
              <p className="text-[11px] text-slate-500 mt-1">Terdaftar dalam rekam medis</p>
            </div>

            <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs">
              <span className="text-xs font-bold text-slate-400 uppercase">Kepuasan Rata-Rata</span>
              <div className="text-2xl font-black text-amber-600 mt-1">{analytics.averageRating} ★</div>
              <p className="text-[11px] text-slate-500 mt-1">Dari ulasan yang disetujui publik</p>
            </div>
          </div>

          {/* Demografi Keluhan Pasien & Distribusi Masalah */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
              <h3 className="text-base font-bold text-slate-900 mb-1">Demografi Keluhan Psikologis Pasien</h3>
              <p className="text-xs text-slate-500 mb-6">Distribusi masalah utama yang dilaporkan saat mengisi formulir intake.</p>

              <div className="space-y-4">
                {analytics.topConcerns.map(item => (
                  <div key={item.name}>
                    <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                      <span>{item.name}</span>
                      <span className="text-slate-500">
                        {item.count} kasus ({item.percentage}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                      <div className="bg-purple-600 h-full rounded-full" style={{ width: `${item.percentage}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Performa Psikolog */}
            <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
              <h3 className="text-base font-bold text-slate-900 mb-1">Performa Psikolog Aktif</h3>
              <p className="text-xs text-slate-500 mb-4">Statistik pemenuhan sesi dan rating profesional.</p>

              <div className="space-y-3">
                {psychologists.map(psy => {
                  const u = users.find(user => user.id === psy.userId);
                  const psyApts = appointments.filter(a => a.psychologistId === psy.userId);
                  return (
                    <div
                      key={psy.userId}
                      className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/70 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <img src={u?.avatar} alt={u?.name} className="w-10 h-10 rounded-xl object-cover" />
                        <div>
                          <div className="text-xs font-bold text-slate-900">{u?.name}</div>
                          <div className="text-[11px] text-slate-500">{psy.title}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs font-extrabold text-slate-900">{psyApts.length} Sesi Terjadwal</div>
                        <div className="text-[11px] text-amber-600 font-bold">{psy.rating} ★ ({psy.reviewCount} ulasan)</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: USER MANAGEMENT & VERIFIKASI PSIKOLOG */}
      {activeAdminTab === 'users' && (
        <div className="py-6 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">Manajemen Pengguna & Verifikasi Kredensial</h3>
                <p className="text-xs text-slate-500">
                  Verifikasi nomor STR / SIP psikolog yang baru mendaftar sebelum mereka dapat menerima pasien.
                </p>
              </div>
              <span className="text-xs font-bold text-slate-600">{users.length} Total User</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-500 uppercase font-bold text-[10px] border-y border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Nama & Email</th>
                    <th className="py-3 px-4">Role</th>
                    <th className="py-3 px-4">Status Akun</th>
                    <th className="py-3 px-4">Kredensial STR / SIP</th>
                    <th className="py-3 px-4 text-right">Aksi Administrator</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.map(u => {
                    const psyProfile = psychologists.find(p => p.userId === u.id);
                    return (
                      <tr key={u.id} className="hover:bg-slate-50/80">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <img src={u.avatar} alt={u.name} className="w-9 h-9 rounded-xl object-cover" />
                            <div>
                              <div className="font-bold text-slate-900">{u.name}</div>
                              <div className="text-[11px] text-slate-500">{u.email}</div>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              u.role === 'ADMIN'
                                ? 'bg-purple-100 text-purple-800'
                                : u.role === 'PSYCHOLOGIST'
                                ? 'bg-sky-100 text-sky-800'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {u.role}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              u.status === 'ACTIVE'
                                ? 'bg-emerald-100 text-emerald-800'
                                : u.status === 'PENDING_VERIFICATION'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {u.status}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          {psyProfile ? (
                            <div className="text-[11px] font-mono text-slate-600">
                              <div>SIP: {psyProfile.sipNumber}</div>
                              <div>STR: {psyProfile.strNumber}</div>
                            </div>
                          ) : (
                            <span className="text-slate-400">-</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            {u.status === 'PENDING_VERIFICATION' && (
                              <button
                                onClick={() => toggleUserStatus(u.id, 'ACTIVE')}
                                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                Verifikasi & Aktifkan
                              </button>
                            )}
                            {u.status === 'ACTIVE' && u.role !== 'ADMIN' && (
                              <button
                                onClick={() => toggleUserStatus(u.id, 'BLOCKED')}
                                className="px-2.5 py-1 text-slate-600 hover:text-rose-600 hover:bg-rose-50 rounded-lg text-xs font-semibold"
                                title="Blokir akses pengguna"
                              >
                                <Lock className="w-3.5 h-3.5" />
                              </button>
                            )}
                            {u.status === 'BLOCKED' && (
                              <button
                                onClick={() => toggleUserStatus(u.id, 'ACTIVE')}
                                className="px-2.5 py-1 text-slate-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg text-xs font-semibold"
                                title="Buka blokir akses"
                              >
                                <Unlock className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: MONITORING RESERVASI & TRANSAKSI */}
      {activeAdminTab === 'reservations' && (
        <div className="py-6 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 mb-4 gap-3">
              <div>
                <h3 className="text-base font-bold text-slate-900">Pengawasan Reservasi & Status Transaksi</h3>
                <p className="text-xs text-slate-500">Pantau seluruh janji temu antara pasien dan psikolog secara transparan.</p>
              </div>

              {/* Status Filter */}
              <div className="flex gap-1.5">
                {['ALL', 'CONFIRMED', 'PENDING', 'COMPLETED', 'CANCELLED'].map(st => (
                  <button
                    key={st}
                    onClick={() => setResStatusFilter(st)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                      resStatusFilter === st
                        ? 'bg-purple-700 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-500 uppercase font-bold text-[10px] border-y border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Kode Booking</th>
                    <th className="py-3 px-4">Pasien</th>
                    <th className="py-3 px-4">Psikolog</th>
                    <th className="py-3 px-4">Paket & Biaya</th>
                    <th className="py-3 px-4">Waktu</th>
                    <th className="py-3 px-4">Status Sesi</th>
                    <th className="py-3 px-4 text-right">Ubah Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredAppointments.map(apt => (
                    <tr key={apt.id} className="hover:bg-slate-50/80">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">{apt.bookingCode}</td>
                      <td className="py-3 px-4 font-semibold text-slate-800">{apt.patientName}</td>
                      <td className="py-3 px-4 text-slate-700">{apt.psychologistName.split(',')[0]}</td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{apt.packageName}</div>
                        <div className="text-[10px] text-emerald-700 font-bold">
                          Rp {apt.totalAmount.toLocaleString('id-ID')} ({apt.paymentStatus})
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        {apt.date} {apt.startTime}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            apt.status === 'CONFIRMED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : apt.status === 'COMPLETED'
                              ? 'bg-slate-200 text-slate-800'
                              : apt.status === 'PENDING'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {apt.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          {apt.status !== 'COMPLETED' && (
                            <button
                              onClick={() => updateAppointmentStatus(apt.id, 'COMPLETED')}
                              className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[11px] font-bold"
                            >
                              Selesai
                            </button>
                          )}
                          {apt.status !== 'CANCELLED' && (
                            <button
                              onClick={() => updateAppointmentStatus(apt.id, 'CANCELLED')}
                              className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded text-[11px] font-bold"
                            >
                              Batal
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: MODERASI REVIEW PASIEN */}
      {activeAdminTab === 'reviews' && (
        <div className="py-6 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
            <h3 className="text-base font-bold text-slate-900 mb-1">Moderasi Testimoni & Rating Pasien</h3>
            <p className="text-xs text-slate-500 mb-6">
              Review baru dari pasien harus disetujui oleh admin sebelum ditampilkan pada landing page publik demi menjaga etika dan privasi klinis.
            </p>

            <div className="space-y-4">
              {reviews.map(rev => (
                <div
                  key={rev.id}
                  className={`p-5 rounded-2xl border transition-all ${
                    rev.isApproved ? 'bg-slate-50/70 border-slate-200' : 'bg-amber-50/60 border-amber-300'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <div className="flex text-amber-500">
                        {[...Array(rev.rating)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                        ))}
                      </div>
                      <span className="text-xs font-bold text-slate-800">
                        {rev.isAnonymous ? rev.anonymousAlias : rev.patientName}
                      </span>
                      {rev.isAnonymous && (
                        <span className="text-[10px] bg-slate-200 text-slate-700 font-semibold px-1.5 py-0.2 rounded">
                          Anonim
                        </span>
                      )}
                    </div>

                    <div>
                      {rev.isApproved ? (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> Disetujui (Tampil di Landing Page)
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-200 text-amber-900 flex items-center gap-1">
                          <Clock className="w-3 h-3" /> Menunggu Persetujuan
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-slate-700 leading-relaxed italic my-2">"{rev.comment}"</p>

                  <div className="pt-3 border-t border-slate-200/80 flex items-center justify-between text-xs">
                    <span className="text-slate-500">
                      Ditujukan untuk: <strong>{rev.psychologistName}</strong> • {rev.createdAt}
                    </span>

                    <div className="flex items-center gap-2">
                      {!rev.isApproved && (
                        <button
                          onClick={() => approveReview(rev.id)}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs"
                        >
                          <Check className="w-3.5 h-3.5" />
                          Setujui & Publikasikan
                        </button>
                      )}
                      <button
                        onClick={() => rejectReview(rev.id)}
                        className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg text-xs font-bold flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Tolak / Hapus
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: MANAJEMEN PAKET KONSULTASI */}
      {activeAdminTab === 'packages' && (
        <div className="py-6 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
              <div>
                <h3 className="text-base font-bold text-slate-900">Katalog Paket Layanan Konsultasi</h3>
                <p className="text-xs text-slate-500">Atur paket, harga sesi, durasi, dan fasilitas yang didapatkan pasien.</p>
              </div>
              <button
                onClick={handleOpenNewPackage}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                Tambah Paket Baru
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {packages.map(pkg => (
                <div key={pkg.id} className="p-5 rounded-2xl border border-slate-200 bg-slate-50/70 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-[10px] font-mono text-slate-400">{pkg.type}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        {pkg.isActive ? 'Aktif' : 'Nonaktif'}
                      </span>
                    </div>
                    <h4 className="text-base font-bold text-slate-900">{pkg.name}</h4>
                    <p className="text-xs text-slate-500 mt-1">{pkg.durationMinutes} Menit Sesi</p>
                    <div className="text-lg font-extrabold text-purple-900 my-2">
                      Rp {pkg.price.toLocaleString('id-ID')}
                    </div>
                    <ul className="text-xs text-slate-600 space-y-1 my-3 pl-2">
                      {pkg.benefits.map((b, i) => (
                        <li key={i}>• {b}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                    <button
                      onClick={() => deletePackage(pkg.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: INSTRUMEN TES PSIKOLOGI */}
      {activeAdminTab === 'tests' && (
        <div className="py-6 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
            <div className="pb-4 border-b border-slate-100 mb-6">
              <h3 className="text-base font-bold text-slate-900">Instrumen Asesmen Psikologi Terintegrasi</h3>
              <p className="text-xs text-slate-500">
                Formula penilaian dan butir-butir pertanyaan kuesioner baku (DASS-21, PHQ-9).
              </p>
            </div>

            <div className="space-y-6">
              {tests.map(t => (
                <div key={t.id} className="p-6 rounded-2xl border border-slate-200 bg-slate-50">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <span className="text-xs font-bold text-purple-700 uppercase">{t.code}</span>
                      <h4 className="text-lg font-bold text-slate-900">{t.title}</h4>
                    </div>
                    <span className="text-xs font-bold text-slate-500">{t.questions.length} Butir Pertanyaan</span>
                  </div>

                  <p className="text-xs text-slate-600 mt-1 mb-3">{t.shortDescription}</p>

                  <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs">
                    <span className="font-bold text-slate-700 block mb-1">Formula & Pedoman Penilaian:</span>
                    <p className="text-slate-600">{t.scoringFormula}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Modal CRUD Package */}
      {isPackageModalOpen && editingPackage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100 mb-4">
              <h4 className="text-base font-bold text-slate-900">Tambah / Edit Paket Konsultasi</h4>
              <button onClick={() => setIsPackageModalOpen(false)} className="text-slate-400 font-bold">
                ✕
              </button>
            </div>

            <form onSubmit={handleSavePackageSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Nama Paket</label>
                <input
                  type="text"
                  required
                  value={editingPackage.name}
                  onChange={e => setEditingPackage({ ...editingPackage, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Tipe Paket</label>
                  <select
                    value={editingPackage.type}
                    onChange={e => setEditingPackage({ ...editingPackage, type: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
                  >
                    <option value="ONLINE_CHAT">ONLINE_CHAT</option>
                    <option value="OFFLINE_CLINIC">OFFLINE_CLINIC</option>
                    <option value="BUNDLING_ASSESSMENT">BUNDLING_ASSESSMENT</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Durasi (Menit)</label>
                  <input
                    type="number"
                    required
                    value={editingPackage.durationMinutes}
                    onChange={e => setEditingPackage({ ...editingPackage, durationMinutes: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Harga (Rp)</label>
                <input
                  type="number"
                  required
                  value={editingPackage.price}
                  onChange={e => setEditingPackage({ ...editingPackage, price: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Deskripsi Singkat</label>
                <textarea
                  rows={2}
                  value={editingPackage.description}
                  onChange={e => setEditingPackage({ ...editingPackage, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsPackageModalOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow-xs"
                >
                  Simpan Paket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
